//
//  TableViewPastEventsCell.swift
//  Sultani Makutano
//
//  Created by vidhi jayswal on 08/06/19.
//  Copyright © 2019 vidhi jayswal. All rights reserved.
//

import UIKit

class TableViewPastEventsCell: UITableViewCell
{

    
    @IBOutlet weak var lblDay: UILabel!
    
    @IBOutlet weak var lblDate: UILabel!
    
    @IBOutlet weak var lblEventName: UILabel!
    
    @IBOutlet weak var lblAddress: UILabel!
    
    
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
