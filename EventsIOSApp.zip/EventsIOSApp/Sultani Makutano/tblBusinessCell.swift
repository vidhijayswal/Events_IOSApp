//
//  tblBusinessCell.swift
//  Sultani Mukhtano
//
//  Created by sanjay bhatia on 06/06/19.
//  Copyright © 2019 sanjay bhatia. All rights reserved.
//

import UIKit

class tblBusinessCell: UITableViewCell {
    
    
    
    @IBOutlet weak var BackView: UIView!
    
    
    @IBOutlet weak var imgBusinessLogo: UIImageView!
    
    
    @IBOutlet weak var lblBusinessName: UILabel!
    @IBOutlet weak var lblPlace: UILabel!
    
    @IBOutlet weak var btnLike: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
