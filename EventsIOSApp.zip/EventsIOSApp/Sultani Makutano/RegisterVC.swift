//
//  RegisterVC.swift
//  Sultani Makutano
//
//  Created by vidhi jayswal on 08/06/19.
//  Copyright © 2019 vidhi jayswal. All rights reserved.
//

import UIKit
//import Alamofire
//import SVProgressHUD
//import CTKFlagPhoneNumber

class RegisterVC: UIViewController, UITextFieldDelegate
{
    
    //-------------------
    // MARK: Outlets
    //-------------------
    
    
    @IBOutlet weak var lblName: UILabel!
    
    @IBOutlet weak var txtName: UITextField!
    
    @IBOutlet weak var lblNameError: UILabel!
    
    @IBOutlet weak var lblEmail: UILabel!
    
    @IBOutlet weak var txtEmail: UITextField!
    
    @IBOutlet weak var lblEmailError: UILabel!
    
    @IBOutlet weak var lblPassword: UILabel!
    
    @IBOutlet weak var txtPassword: UITextField!
    
    @IBOutlet weak var lblPasswordError: UILabel!
    
    @IBOutlet weak var lblConfirmPassword: UILabel!
    
    
    @IBOutlet weak var txtConfirmPassword: UITextField!
    
    @IBOutlet weak var lblConfirmPasswordError: UILabel!
    
    @IBOutlet weak var lblBirthday: UILabel!
    
    @IBOutlet weak var txtBirthdate: UITextField!
    
    @IBOutlet weak var lblBirthdateError: UILabel!
    
    @IBOutlet weak var lblPhoneNumber: UILabel!
    
    @IBOutlet weak var txtPhoneNumber: CTKFlagPhoneNumberTextField!
    
    
    @IBOutlet weak var lblPhoneNumberError: UILabel!
    
    
    @IBOutlet weak var lblAddress: UILabel!
    
    @IBOutlet weak var txtAddress: UITextField!
    
    @IBOutlet weak var lblAddressError: UILabel!
    
    
    @IBOutlet weak var btnCheckBox: UIButton!
    
    @IBOutlet weak var btnMale: UIButton!
    
    @IBOutlet weak var btnFemale: UIButton!
    
    @IBOutlet weak var scrollView: UIScrollView!
    
    
    
    //-------------------
    // MARK: Identifiers
    //-------------------
    
    var timer = Timer()
    
    var gender = Int()
    
    var role = Int()
    
    
    
    //-----------------------
    // MARK: View Life Cycle
    //-----------------------
    

    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        lblNameError.isHidden = true
        lblEmailError.isHidden = true
        lblPasswordError.isHidden = true
        lblConfirmPasswordError.isHidden = true
        lblBirthdateError.isHidden = true
        lblPhoneNumberError.isHidden = true
        lblAddressError.isHidden = true
        
        
        
        
        lblName.isHidden = true
        lblEmail.isHidden = true
        lblConfirmPassword.isHidden = true
        lblPassword.isHidden = true
        lblConfirmPassword.isHidden = true
        lblBirthday.isHidden = true
        lblPhoneNumber.isHidden = true
        
        
        
        
        
        txtName.delegate = self
        txtEmail.delegate = self
        txtPassword.delegate = self
        txtConfirmPassword.delegate = self
        txtBirthdate.delegate = self
        txtPhoneNumber.delegate = self
        txtAddress.delegate = self
        
        
        
        
        txtName.addTarget(self, action: #selector(txtNameValueChanged), for: .editingChanged)
        txtEmail.addTarget(self, action: #selector(txtEmailValueChanged), for: .editingChanged)
        
        txtPassword.addTarget(self, action: #selector(txtPasswordValueChanged), for: .editingChanged)
        txtConfirmPassword.addTarget(self, action: #selector(txtConfirmPasswordValueChanged), for: .editingChanged)
        
        txtBirthdate.addTarget(self, action: #selector(txtBirthdateValueChanged), for: .editingChanged)
        txtPhoneNumber.addTarget(self, action: #selector(txtPhoneNumberValueChanged), for: .editingChanged)
        
        txtAddress.addTarget(self, action: #selector(txtAddressValueChanged), for: .editingChanged)
        
        
        txtPhoneNumber.setFlag(for:"INDIA")
        
        
        self.hideKeyboardTappedArround()
        

    }
    

    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        registerKeyboardNotifications()
    }
    
    
    
    //--------------------------
    // MARK: Delegate Methods
    //--------------------------
    
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        self.view.endEditing(true)
    }
    
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        textField.resignFirstResponder()
        self.view.endEditing(true)
        return true
    }
    
    
    func registerKeyboardNotifications()
    {
        NotificationCenter.default.addObserver(self,selector: #selector(keyboardWillShow(notification:)),name: UIResponder.keyboardWillShowNotification,object: nil)
        
        NotificationCenter.default.addObserver(self,selector: #selector(keyboardWillHide(notification:)),name: UIResponder.keyboardWillHideNotification,object: nil)
    }
    
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        scrollView.setContentOffset(CGPoint(x: 0, y: 250), animated: true)
    }
    
    
    
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        scrollView.setContentOffset(CGPoint(x: 0, y: 0), animated: true)
    }
    
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool
    {
        if textField.tag == 1
        {
            let currentText = textField.text ?? ""
            guard let stringRange = Range(range, in: currentText) else
            {
                return false
            }
            
            let updatedText = currentText.replacingCharacters(in: stringRange, with: string)
            
            return updatedText.count <= 11
            
        }
        return true
        
    }
    
    
    
    
    
    
    
    
    
    
    //------------------------------
    // MARK: User Defined Functions
    //------------------------------
    
    
    @objc func txtNameValueChanged()
    {
        if txtName.text == ""
        {
            lblName.isHidden = true
            lblNameError.isHidden = false
        }
        else
        {
            lblName.isHidden = false
            lblNameError.isHidden = true
        }
    }
    
    
    @objc func txtEmailValueChanged()
    {
        if txtEmail.text == ""
        {
            lblEmail.isHidden = true
            lblEmailError.isHidden = false
        }
        else
        {
            lblEmail.isHidden = false
            lblEmailError.isHidden = true
        }
    }
    
    @objc func txtPhoneNumberValueChanged()
    {
        if txtPhoneNumber.text == ""
        {
            lblPhoneNumber.isHidden = true
            lblPhoneNumberError.isHidden = false
        }
        else
        {
            lblPhoneNumber.isHidden = false
            lblPhoneNumberError.isHidden = true
        }
    }
    
    @objc func txtPasswordValueChanged()
    {
        if txtPassword.text == ""
        {
            lblPassword.isHidden = true
            lblPasswordError.isHidden = false
        }
        else
        {
            lblPassword.isHidden = false
            lblPasswordError.isHidden = true
        }
    }
    
    @objc func txtConfirmPasswordValueChanged()
    {
        if txtConfirmPassword.text == ""
        {
            lblConfirmPassword.isHidden = true
            lblConfirmPasswordError.isHidden = false
        }
        else
        {
            lblConfirmPassword.isHidden = false
            lblConfirmPasswordError.isHidden = true
        }
    }
    
    @objc func txtBirthdateValueChanged()
    {
        if txtConfirmPassword.text == ""
        {
            lblConfirmPassword.isHidden = true
            lblConfirmPasswordError.isHidden = false
        }
        else
        {
            lblConfirmPassword.isHidden = false
            lblConfirmPasswordError.isHidden = true
        }
    }
    
    @objc func txtAddressValueChanged()
    {
        if txtAddress.text == ""
        {
            lblAddress.isHidden = true
            lblAddressError.isHidden = false
        }
        else
        {
            lblAddress.isHidden = false
            lblAddressError.isHidden = true
        }
    }
    
    
    
    
    
//    @objc func InternetAvailable()
//    {
//        if Connectivity.isConnectedToInternet()
//        {
//            registerAPI()
//        }
//        else
//        {
//            SVProgressHUD.dismiss()
//            PopUp(Controller: self, title: "Internet Connectivity", message: "Internet Not Available")
//        }
//    }
    
    
    
    @objc func keyboardWillShow(notification: NSNotification)
    {
        let userInfo: NSDictionary = notification.userInfo! as NSDictionary
        let keyboardInfo = userInfo[UIResponder.keyboardFrameEndUserInfoKey] as! NSValue
        let keyboardSize = keyboardInfo.cgRectValue.size
        let contentInsets = UIEdgeInsets(top: 0, left: 0, bottom: keyboardSize.height, right: 0)
        scrollView.contentInset = contentInsets
        scrollView.scrollIndicatorInsets = contentInsets
    }
    
    @objc func keyboardWillHide(notification: NSNotification)
    {
        scrollView.contentInset = .zero
        scrollView.scrollIndicatorInsets = .zero
    }
    
    
    
    
    
    
    
    
    //----------------------
    // MARK: Button Actions
    //----------------------
    
    
    @IBAction func btnRegister(_ sender: UIButton)
    {
        
        let obj = storyboard?.instantiateViewController(withIdentifier: "mainscreenVC") as! mainscreenVC
        
        obj.type = role
        
        navigationController?.pushViewController(obj, animated: true)
        
    }
    
    
    
    @IBAction func btnBACK(_ sender: UIButton)
    {
        navigationController?.popViewController(animated: true)
    }
    
    
    
    
    @IBAction func btnMaleTUI(_ sender: UIButton)
    {
        if !btnMale.isSelected
        {
            btnMale.isSelected = true
            btnFemale.isSelected = false
            gender = 1
        }
    }
    
    @IBAction func btnFemaleTUI(_ sender: UIButton)
    {
        if !btnFemale.isSelected
        {
            btnFemale.isSelected = true
            btnMale.isSelected = false
            gender = 2
        }
    }
    
    
    @IBAction func btnCheckbox(_ sender: UIButton)
    {
        if !btnCheckBox.isSelected
        {
            btnCheckBox.isSelected = true
        }
        else
        {
            btnCheckBox.isSelected = false
        }
    }
    
    
    
    
    //-------------------
    // MARK: Web Service
    //-------------------
    
    
    
}


//------------------------------------
//MARK: Extension
//------------------------------------

extension  UIViewController
{
    func hideKeyboardTappedArround()
    {
        let tap:UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dissmissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    @objc func dissmissKeyboard()
    {
        self.view.endEditing(true)
    }
}
