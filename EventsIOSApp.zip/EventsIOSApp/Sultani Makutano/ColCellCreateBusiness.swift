//
//  ColCellCreateBusiness.swift
//  Sultani Mukhtano
//
//  Created by sanjay bhatia on 07/06/19.
//  Copyright © 2019 sanjay bhatia. All rights reserved.
//

import UIKit

class ColCellCreateBusiness: UICollectionViewCell

{
    
    @IBOutlet weak var imgBusiness: UIImageView!
    
    
}
