//
//  EventsVC.swift
//  Sultani Makutano
//
//  Created by vidhi jayswal on 08/06/19.
//  Copyright © 2019 vidhi jayswal. All rights reserved.
//

import UIKit

class EventsVC: UIViewController
{
    
    
    //-------------------
    // MARK: Outlets
    //-------------------
    
    
    
    @IBOutlet weak var containerView: UIView!
    
    
    @IBOutlet weak var btnUpcoming: UIButton!
    
    @IBOutlet weak var btnPast: UIButton!
    
    //-------------------
    // MARK: Identifiers
    //-------------------
    
    
    var VC = UIViewController()
    
    //-----------------------
    // MARK: View Life Cycle
    //-----------------------
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
          btnUpcoming.backgroundColor = UIColor.black
        
        VC = storyboard?.instantiateViewController(withIdentifier: "UpcomingEventsVC") as! UpcomingEventsVC
        self.addChild(VC)
        VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
        self.containerView.addSubview(VC.view)
        VC.didMove(toParent: self)

        
    }
    
    
    
    
    //----------------------------
    // MARK: User Defined Function
    //----------------------------
    
    
    
    
    
    
    
    
    
    
    
    //----------------------
    // MARK: Button Actions
    //----------------------
    
    @IBAction func btnUpcomingTUI(_ sender: UIButton)
    {
        
        btnUpcoming.backgroundColor = UIColor.black
        
        btnPast.backgroundColor = UIColor.red
        
        VC = storyboard?.instantiateViewController(withIdentifier: "UpcomingEventsVC") as! UpcomingEventsVC
        self.addChild(VC)
        VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
        self.containerView.addSubview(VC.view)
        VC.didMove(toParent: self)
    }
    
    @IBAction func btnPastTUI(_ sender: UIButton)
    {
       
        btnPast.backgroundColor = UIColor.black
        
        btnUpcoming.backgroundColor = UIColor.red
        
        VC = storyboard?.instantiateViewController(withIdentifier: "PastEventsVC") as! PastEventsVC
        self.addChild(VC)
        VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
        self.containerView.addSubview(VC.view)
        VC.didMove(toParent: self)
        
        
    }
    
    
    
    
    
    
    
    //----------------------
    // MARK: Web Service
    //----------------------
    
    
    

}
