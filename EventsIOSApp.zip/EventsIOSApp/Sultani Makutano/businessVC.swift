//
//  businessVC.swift
//  Sultani Mukhtano
//
//  Created by sanjay bhatia on 06/06/19.
//  Copyright © 2019 sanjay bhatia. All rights reserved.
//

import UIKit

class businessVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
   
    
    //-----------------------
    //MARK:Outlets
    //-----------------------
    
 
    
    @IBOutlet weak var tblBusiness: UITableView!
    
    //-------------------------
    // MARK: Identifiers
    //-------------------------
    
    
    var imageArr = [#imageLiteral(resourceName: "icon_logo")]
    var lblBusinessName = ["Food Events","Food Events","Food Events","Food Events","Food Events","Food Events"]
    var lblPlace = ["GMDC"]
    
    
    
    
    //----------------------------
    //MARK: View Life Cycle
    //----------------------------
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
       
        
        
 if(UIDevice.current.userInterfaceIdiom == UIUserInterfaceIdiom.pad)
 {
            tblBusiness.rowHeight = 200;
    
 }
    else {
            tblBusiness.rowHeight = 150
    ;
        }
       

        // Do any additional setup after loading the view.
    }
    
   
    
    //----------------------------
    //MARK: Delegate Methods
    //----------------------------
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 6
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
      let Cell = tableView.dequeueReusableCell(withIdentifier: "tblBusinessCell") as! tblBusinessCell
        
        Cell.imgBusinessLogo.image = imageArr[0]
        Cell.lblBusinessName.text = lblBusinessName[indexPath.row]
        Cell.lblPlace.text = lblPlace[0]
       
        
        Cell.BackView.layer.cornerRadius = 5
        
        Cell.BackView.clipsToBounds = true
        
        return Cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let obj = storyboard?.instantiateViewController(withIdentifier: "BusinessDetailVC") as! BusinessDetailVC
     
        
        navigationController?.pushViewController(obj, animated: true)

        
    }
    
    
    //--------------------------------
    //MARK: User Defined Functions
    //--------------------------------
    
    
    
    //------------------------
    // MARK:Button Actions
    //-----------------------
    
    @IBAction func btnAddBusinessTUI(_ sender: UIButton)
        
    {
        let obj = storyboard?.instantiateViewController(withIdentifier: "AddBusinessVC") as! AddBusinessVC
        
        
        navigationController?.pushViewController(obj, animated: true)
        
        
    }
    //------------------------
    // MARK:Web Services
    //-----------------------

  
    
}





