//
//  TableViewCell.swift
//  new_ios_application
//
//  Created by vidhi jayswal on 04/04/19.
//  Copyright © 2019 vidhi jayswal. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell
{

    
    //-----------------------
    //MARK: Outlets
    //-----------------------
    
    @IBOutlet weak var lblName: UILabel!
    
    @IBOutlet weak var uiview: UIView!
    
    @IBOutlet weak var img: UIImageView!
    
    
    
    //-----------------------
    //MARK: View life cycle
    //-----------------------
    
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        }

}
