//
//  EventCreateVC.swift
//  Sultani Mukhtano
//
//  Created by sanjay bhatia on 08/06/19.
//  Copyright © 2019 sanjay bhatia. All rights reserved.
//

import UIKit

class EventCreateVC: UIViewController, UITextFieldDelegate, UITextViewDelegate
{
    
    //-----------------------
    //MARK:Outlets
    //-----------------------
    
    @IBOutlet weak var createEventScrollView: UIScrollView!
    
    @IBOutlet weak var lblOrgNamePalceholder: UILabel!
    
    @IBOutlet weak var txtOrgName: UITextField!
    
    @IBOutlet weak var lblOrgError: UILabel!
    
    @IBOutlet weak var lblEventNamePlaceholder: UILabel!
    
    @IBOutlet weak var txtEventName: UITextField!
    
    @IBOutlet weak var lblEventError: UILabel!
    
    @IBOutlet weak var lblDescriptionPlaceholder: UILabel!
    
    @IBOutlet weak var txtViewDescription: UITextView!
    
    @IBOutlet weak var lblDescriptionError: UILabel!
    
    @IBOutlet weak var lblAddressPlaceholder: UILabel!
    
    @IBOutlet weak var txtViewAddress: UITextView!
    
    @IBOutlet weak var lblAddressError: UILabel!
    
    @IBOutlet weak var lblStartDatepPaceholder: UILabel!
    
    @IBOutlet weak var txtStartDate: UITextField!
    
    @IBOutlet weak var lblStartDateError: UILabel!
    
    @IBOutlet weak var lblEndDatePlaceholder: UILabel!
    
    @IBOutlet weak var txtEndDate: UITextField!
    
    @IBOutlet weak var lblEndDateError: UILabel!
    
    @IBOutlet weak var lblStartTimePlaceholder: UILabel!

    @IBOutlet weak var txtStartTime: UITextField!
    
    @IBOutlet weak var lblStartTimeError: UILabel!

    @IBOutlet weak var lblEndTimePlaceholder: UILabel!
    
    @IBOutlet weak var txtEndTime: UITextField!
    
    @IBOutlet weak var lblEndTimeError: UILabel!
    
    
    @IBOutlet weak var imgAdd: UIImageView!
    
    
    //-------------------------
    // MARK: Identifiers
    //-------------------------
    
    
    
    //----------------------------
    //MARK: View Life Cycle
    //----------------------------
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

       
        lblOrgNamePalceholder.isHidden = true
        
        lblOrgError.isHidden = true
        
        lblEventNamePlaceholder.isHidden = true
        
        lblEventError.isHidden = true
        
        lblDescriptionError.isHidden = true
        
        lblAddressError.isHidden = true
        
        lblStartDatepPaceholder.isHidden = true
        
        lblStartDateError.isHidden = true
        
        lblStartTimePlaceholder.isHidden = true
        
        lblStartTimeError.isHidden = true
        
        lblEndDatePlaceholder.isHidden = true
        
        lblEndDateError.isHidden = true
        
        lblEndTimePlaceholder.isHidden = true
        
        lblEndTimeError.isHidden = true
        
//-----------------------------------------------------------
        
        
        txtOrgName.delegate = self
        
        txtEventName.delegate = self
        
        txtViewDescription.delegate = self

        txtViewAddress.delegate = self
//
        txtStartDate.delegate = self
        
        txtEndDate.delegate = self
        
        txtStartTime.delegate = self
        
        txtEndTime.delegate = self
        
//        txtViewDescription.layer.borderWidth = 0.5
//        txtViewDescription.layer.borderColor = UIColor.lightGray.cgColor
//        txtViewDescription.layer.cornerRadius = txtViewDescription.frame.size.height/6
//
//
//        txtViewAddress.layer.borderWidth = 0.5
//        txtViewAddress.layer.borderColor = UIColor.lightGray.cgColor
//        txtViewAddress.layer.cornerRadius = txtViewAddress.frame.size.height/6

      
//-----------------------------------------------------------

        
        txtOrgName.addTarget(self, action: #selector(txtOrgNameValueChange), for: .editingChanged)
       
        txtEventName.addTarget(self, action: #selector(txtEventNameValueChange), for: .editingChanged)
        
//        txtDescription.addTarget(self, action: #selector(txtEventDescriptionValueChange), for: .editingChanged)
//
//        txtAddress.addTarget(self, action: #selector(txtAddressValueChange), for: .editingChanged)
        
          txtStartDate.addTarget(self, action: #selector(txtStartDateValueChange), for: .editingChanged)
        
          txtEndDate.addTarget(self, action: #selector(txtEndDateValueChange), for: .editingChanged)
        
        txtStartTime.addTarget(self, action: #selector(txtStartTimeValueChange), for: .editingChanged)
        
        txtEndTime.addTarget(self, action: #selector(txtEndTimeValueChange), for: .editingChanged)
    
//-----------------------------------------------------------

        
        txtOrgName.attributedPlaceholder = NSMutableAttributedString(string: "Enter Organizer Name",attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray])
        
        txtEventName.attributedPlaceholder = NSMutableAttributedString(string: "Enter Event Name ",attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray])
        
//        txtDescription.attributedPlaceholder = NSMutableAttributedString(string: "Enter Description",attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray])
//        
//        txtAddress.attributedPlaceholder = NSMutableAttributedString(string: "Enter Address",attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray])
        
        
        
        txtStartDate.attributedPlaceholder = NSMutableAttributedString(string: "Enter Start Date",attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray])
        
        txtEndDate.attributedPlaceholder = NSMutableAttributedString(string: "Enter End Date ID",attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray])
        
        txtStartTime.attributedPlaceholder = NSMutableAttributedString(string: "Enter Start Time",attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray])
        
        txtEndTime.attributedPlaceholder = NSMutableAttributedString(string: "Enter End Time",attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray])
        
    }
    

  
    
    
    //----------------------------
    //MARK: Delegate Methods
    //----------------------------
    
    
    
    
    
    
    //--------------------------------
    //MARK: User Defined Functions
    //--------------------------------
    
    
    @objc func txtOrgNameValueChange()
    {
        if txtOrgName.text == ""
        {
            lblOrgNamePalceholder.isHidden = true
            lblOrgError.isHidden = false
        }
        else
        {
            lblOrgNamePalceholder.isHidden = false
            lblOrgError.isHidden = true
        }
    }
    
    @objc func txtEventNameValueChange()
    {
        if txtEventName.text == ""
        {
            lblEventNamePlaceholder.isHidden = true
            lblEventError.isHidden = false
        }
        else
        {
            lblEventNamePlaceholder.isHidden = false
            lblEventError.isHidden = true
        }
        
        
    }
    
    
    func textViewDidChange(_ textView: UITextView)
    {
        if textView.tag == 1
        {
            if txtViewDescription.text == ""
            {
                lblDescriptionError.isHidden = false
            }
            else
            {
                lblDescriptionError.isHidden = true
            }
        }
        else
        {
            if txtViewAddress.text == ""
            {
                lblAddressError.isHidden = false
            }
            else
            {
                lblAddressError.isHidden = true
            }
        }
        
    }
    
    
//    func textViewDidChange(_ textView: UITextView)
//    {
//        if txtMessage.text == ""
//        {
//            lblMessageError.isHidden = false
//        }
//        else
//        {
//            lblMessageError.isHidden = true
//        }
//    }

//    @objc func txtEventDescriptionValueChange()
//    {
//        if txtViewDescription.text == ""
//        {
//            lblDescriptionError.isHidden = false
//        }
//        else
//        {
//            lblDescriptionError.isHidden = true
//        }
//    }
//
//    @objc func txtAddressValueChange()
//    {
//        if txtViewAddress.text == ""
//        {
//            lblAddressError.isHidden = false
//        }
//        else
//        {
//            lblAddressError.isHidden = true
//        }
//    }

    
    @objc func txtStartDateValueChange()
    {
        if txtStartDate.text == ""
        {
            lblStartDatepPaceholder.isHidden = true
            lblStartDateError.isHidden = false
        }
        else
        {
            lblStartDatepPaceholder.isHidden = false
            lblStartDateError.isHidden = true
        }
    }
    
    @objc func txtEndDateValueChange()
    {
        if txtEndDate.text == ""
        {
            lblEndDatePlaceholder.isHidden = true
            lblEndDateError.isHidden = false
        }
        else
        {
            lblEndDatePlaceholder.isHidden = false
            lblEndDateError.isHidden = true
        }
    }
    
    
    @objc func txtStartTimeValueChange()
    {
        if txtEndTime.text == ""
        {
            lblEndTimePlaceholder.isHidden = true
            lblEndTimeError.isHidden = false
        }
        else
        {
            lblEndTimePlaceholder.isHidden = false
            lblEndTimeError.isHidden = true
        }
    }
    
    
    @objc func txtEndTimeValueChange()
    {
        if txtEndTime.text == ""
        {
            lblEndDatePlaceholder.isHidden = true
            lblEndDateError.isHidden = false
        }
        else
        {
            lblEndDatePlaceholder.isHidden = false
            lblEndDateError.isHidden = true
        }
    }
    
//-----------------------------------------------------------

    @objc func keyboardWillShow(notification:NSNotification){
        //give room at the bottom of the scroll view, so it doesn't cover up anything the user needs to tap
        var userInfo = notification.userInfo!
        var keyboardFrame:CGRect = (userInfo[UIResponder.keyboardFrameBeginUserInfoKey] as! NSValue).cgRectValue
        keyboardFrame = self.view.convert(keyboardFrame, from: nil)
        
        var contentInset:UIEdgeInsets = self.createEventScrollView.contentInset
        contentInset.bottom = keyboardFrame.size.height + 40
        createEventScrollView.contentInset = contentInset
    }
    
    @objc func keyboardWillHide(notification:NSNotification){
        let contentInset:UIEdgeInsets = UIEdgeInsets.zero
        createEventScrollView.contentInset = contentInset
    }
    
    
    //------------------------
    // MARK:Button Actions
    //-----------------------
    
    
    
    
    
    
    
    
    //------------------------
    // MARK:Web Services
    //-----------------------


}
