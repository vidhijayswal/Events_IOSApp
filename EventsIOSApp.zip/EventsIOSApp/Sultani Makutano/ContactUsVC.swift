//
//  ContactUsVC.swift
//  Sultani Mukhtano
//
//  Created by sanjay bhatia on 07/06/19.
//  Copyright © 2019 sanjay bhatia. All rights reserved.
//

import UIKit

class ContactUsVC: UIViewController,UITextFieldDelegate
{

    // -----------------------
    // MARK:Outlets
    // -----------------------

    
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var lblNamePlaceholder: UILabel!
    @IBOutlet weak var lblNameError: UILabel!
    @IBOutlet weak var lblEmailPlaceholder: UILabel!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var lblEmailError: UILabel!
    @IBOutlet weak var lblPhonePlaceholder: UILabel!
    @IBOutlet weak var txtPhone: UITextField!
    @IBOutlet weak var lblPhoneError: UILabel!
    @IBOutlet weak var lblMessagePlaceholder: UILabel!
    @IBOutlet weak var txtViewMessage: UITextView!
    @IBOutlet weak var lblMessageError: UILabel!
    //@IBOutlet weak var btnContact: UIButton!
    @IBOutlet weak var contactScrollView: UIScrollView!
    
    //-------------------------
    // MARK: Identifiers
    //-------------------------
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

       
        lblNameError.isHidden = true
        
        lblNamePlaceholder.isHidden = true
        
        lblEmailError.isHidden = true
        
        lblEmailPlaceholder.isHidden = true
        
        lblPhoneError.isHidden = true
        
        lblPhonePlaceholder.isHidden = true
        
        lblMessageError.isHidden = true
        
//-----------------------------------------------------------

        
        txtName.delegate = self
        
        txtEmail.delegate = self
        
        txtPhone.delegate = self
        
       // txtMessage.delegate = self
        
//-----------------------------------------------------------

        
        txtName.addTarget(self, action: #selector(txtNameValueChange), for: .editingChanged)
        
        txtEmail.addTarget(self, action: #selector(txtEmailValueChange), for: .editingChanged)
        
        txtPhone.addTarget(self, action: #selector(txtPhoneValueChange), for: .editingChanged)
        
      //  txtMessage.addTarget(self, action: #selector(txtMessageValueChange), for: .editingChanged)
        
//-----------------------------------------------------------

        txtName.attributedPlaceholder = NSMutableAttributedString(string: "Enter Name",attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray])
        
        txtEmail.attributedPlaceholder = NSMutableAttributedString(string: "Enter Email ID",attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray])
        
        txtPhone.attributedPlaceholder = NSMutableAttributedString(string: "Enter Phone",attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray])
        
       // txtMessage.attributedPlaceholder = NSMutableAttributedString(string: "Enter Message",attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray])
        
        
    }
    
    //------------------------------------
    // MARK: Delegate Methods
    //------------------------------------
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return true
    }
    
    //------------------------------------
    // MARK: User Defined Functions
    //------------------------------------
    
    @objc func txtNameValueChange()
    {
        if txtName.text == ""
        {
            lblNamePlaceholder.isHidden = true
            lblNameError.isHidden = false
        }
        else
        {
            lblNamePlaceholder.isHidden = false
            lblNameError.isHidden = true
        }
    }
    
    @objc func txtEmailValueChange()
    {
        if txtEmail.text == ""
        {
            lblEmailPlaceholder.isHidden = true
            lblEmailError.isHidden = false
        }
        else
        {
            lblEmailPlaceholder.isHidden = false
            lblEmailError.isHidden = true
        }
        
        
    }
    @objc func txtPhoneValueChange()
    {
        if txtPhone.text == ""
        {
            lblPhonePlaceholder.isHidden = true
            lblPhoneError.isHidden = false
        }
        else
        {
            lblPhonePlaceholder.isHidden = false
            lblPhoneError.isHidden = true
        }
    }
    
    @objc func txtMessageValueChange()
    {
        if txtViewMessage.text == ""
        {
            lblMessageError.isHidden = false
        }
        else
        {
            lblMessageError.isHidden = true
        }
    }
    
//-----------------------------------------------------------

    
    @objc func keyboardWillShow(notification:NSNotification){
       
        var userInfo = notification.userInfo!
        var keyboardFrame:CGRect = (userInfo[UIResponder.keyboardFrameBeginUserInfoKey] as! NSValue).cgRectValue
        keyboardFrame = self.view.convert(keyboardFrame, from: nil)
        
        var contentInset:UIEdgeInsets = self.contactScrollView.contentInset
        contentInset.bottom = keyboardFrame.size.height + 40
        contactScrollView.contentInset = contentInset
    }
    
    @objc func keyboardWillHide(notification:NSNotification){
        let contentInset:UIEdgeInsets = UIEdgeInsets.zero
        contactScrollView.contentInset = contentInset
    }
    
    //------------------------------------
    // MARK: Button Actions
    //------------------------------------
    
    @IBAction func btnSubmitTUI(_ sender: UIButton)
    {
                if txtName.text == "" || (txtName.text! as NSString).trimmingCharacters(in: .whitespaces).isEmpty
                {
                    lblNameError.isHidden = false
                }
                else if txtEmail.text == "" || (txtEmail.text! as NSString).trimmingCharacters(in: .whitespaces).isEmpty
        
                {
                    lblEmailError.isHidden = false
                }
                else if validateEmailWithString(txtEmail.text! as NSString)
                {
                    lblEmailError.text = "Please enter valid Email ID"
                }
                else if txtPhone.text == "" || (txtPhone.text! as NSString).trimmingCharacters(in: .whitespaces).isEmpty
        
                {
                    lblPhoneError.isHidden = false
                }
                else if txtViewMessage.text == "" || (txtViewMessage.text! as NSString).trimmingCharacters(in: .whitespaces).isEmpty
        
                {
                    lblMessageError.isHidden = false
                }
                else
                {
        
        let obj = storyboard?.instantiateViewController(withIdentifier: "CreateBusinessVC") as! CreateBusinessVC
        
        
        navigationController?.pushViewController(obj, animated: true)
        
        // contactUsAPI()
         }
        
    }
    
    
    
    //------------------------------------
    // MARK: Web Services
    //------------------------------------

   

}
