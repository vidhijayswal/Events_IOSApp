//
//  EventDetailVC.swift
//  Sultani Mukhtano
//
//  Created by sanjay bhatia on 07/06/19.
//  Copyright © 2019 sanjay bhatia. All rights reserved.
//

import UIKit

class EventDetailVC: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate {

    
    //-----------------------
    //MARK:Outlets
    //-----------------------
    
    @IBOutlet weak var headerview: UIView!
    
    @IBOutlet weak var colViewEventDetailA: UICollectionView!
    
    @IBOutlet weak var colViewEventDetailB: UICollectionView!
  
    @IBOutlet weak var EventDetailScrollView: UIScrollView!
    
    @IBOutlet weak var imgEventLogo: UIImageView!
    
    @IBOutlet weak var lblEventName: UILabel!
    
    @IBOutlet weak var lblOwnerName: UILabel!
    
    @IBOutlet weak var lblDescription: UILabel!
    
    @IBOutlet weak var lblDate: UILabel!
    
    @IBOutlet weak var lblTime: UILabel!
    
    @IBOutlet weak var lblAddress: UILabel!
    
    @IBOutlet weak var lblRegisterBusiness: UILabel!
    
    //-------------------------
    // MARK: Identifiers
    //-------------------------
    
    var imgArryEventA =  [#imageLiteral(resourceName: "property"),#imageLiteral(resourceName: "icon_logo"),#imageLiteral(resourceName: "Icon_logo_main")]
  
    var imgArryEventB =  [#imageLiteral(resourceName: "property"),#imageLiteral(resourceName: "icon_logo"),#imageLiteral(resourceName: "Icon_logo_main")]

    
    //----------------------------
    //MARK: View Life Cycle
    //----------------------------
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

   
    
    //----------------------------
    //MARK: Delegate Methods
    //----------------------------
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    
    {
       if collectionView.tag == 0
       {
    
            return 2

        }
    
        return 2
    }
    
    

    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
     
      
        
        
        if (collectionView.tag == 0)
        {
         
            let cellA = colViewEventDetailA.dequeueReusableCell(withReuseIdentifier: "ColCellEventDetail", for: indexPath) as! ColCellEventDetail
            
            cellA.imgEventDetailA.image = imgArryEventA[indexPath.row]
            
            return cellA

        }
        else
        {
            let cellB = colViewEventDetailB.dequeueReusableCell(withReuseIdentifier: "ColCellEventDetail", for: indexPath) as! ColCellEventDetail
            
            cellB.imgEventDetailB.image = imgArryEventB[indexPath.row]
            
            return cellB
            
        }

    }
    
    
    
    //--------------------------------
    //MARK: User Defined Functions
    //--------------------------------
    
    
    
    //------------------------
    // MARK:Button Actions
    //-----------------------
    
    @IBAction func btnBackTUI(_ sender: UIButton)
        
    {
        navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func btnEventDetail(_ sender: UIButton) {
    }
    
    //------------------------
    // MARK:Web Services
    //-----------------------
}
