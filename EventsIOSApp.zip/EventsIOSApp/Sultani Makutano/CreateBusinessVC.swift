//
//  CreateBusinessVC.swift
//  Sultani Mukhtano
//
//  Created by sanjay bhatia on 07/06/19.
//  Copyright © 2019 sanjay bhatia. All rights reserved.
//

import UIKit

class CreateBusinessVC: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate,UITextFieldDelegate {
 
    

//    -----------------------
//    MARK:Outlets
//    -----------------------
    
    @IBOutlet weak var headerView: UIView!
    
    @IBOutlet weak var createBusinessScrollView: UIScrollView!
    
    @IBOutlet weak var uploadImageView: UIView!
    
    @IBOutlet weak var imgUploadBusiness: UIImageView!
    
    @IBOutlet weak var btnUploadBusiness: UIButton!
    
    @IBOutlet weak var lblCompanyPlaceholder: UILabel!
    
    @IBOutlet weak var txtCompanyName: UITextField!
    
    @IBOutlet weak var lblCompanyNameError: UILabel!
    
    @IBOutlet weak var lblDescriptionPlaveholder: UILabel!
    
    @IBOutlet weak var txtViewDescription: UITextView!
    
    @IBOutlet weak var lblDescriptionError: UILabel!
    
    @IBOutlet weak var colCellCreateBusiness: UICollectionView!
    
    //-------------------------
    // MARK: Identifiers
    //-------------------------
    
    var uploadImage =  [#imageLiteral(resourceName: "property"),#imageLiteral(resourceName: "icon_logo"),#imageLiteral(resourceName: "Icon_logo_main")]
    
    //----------------------------
    //MARK: View Life Cycle
    //----------------------------
    
    
 
    override func viewDidLoad() {
        super.viewDidLoad()

       
        lblCompanyPlaceholder.isHidden = true
        
        lblCompanyNameError.isHidden = true
        
        lblDescriptionPlaveholder.isHidden = true
        
        lblDescriptionError.isHidden = true
//-----------------------------------------------------------

        
        txtCompanyName.delegate = self
       
       // txtViewDescription.delegate = self
       
//-----------------------------------------------------------

        txtCompanyName.addTarget(self, action: #selector(txtCompanyNameValueChange), for: .editingChanged)
       
        //txtDescription.addTarget(self, action: #selector(txtDescriptionValueChange), for: .editingChanged)
      
        txtCompanyName.attributedPlaceholder = NSMutableAttributedString(string: "Enter Name",attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray])
        
    //    txtDescription.attributedPlaceholder = NSMutableAttributedString(string: "Enter Description",attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray])
        
      
    }
    //----------------------------
    //MARK: Delegate Methods
    //----------------------------
    
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return 3
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
      
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ColCellCreateBusiness", for: indexPath) as! ColCellCreateBusiness
        
        cell.imgBusiness.image = uploadImage[indexPath.row]
        
        
        
        return cell
        
    }
    
    
    //--------------------------------
    //MARK: User Defined Functions
    //--------------------------------
    
    @objc func txtCompanyNameValueChange()
    {
        if txtCompanyName.text == ""
        {
            lblCompanyPlaceholder.isHidden = true
            lblCompanyNameError.isHidden = false
        }
        else
        {
            lblCompanyPlaceholder.isHidden = false
            lblCompanyNameError.isHidden = true
        }
    }
    
    @objc func txtDescriptionValueChange()
    {
        if txtViewDescription.text == ""
        {
            lblDescriptionPlaveholder.isHidden = true
            lblDescriptionError.isHidden = false
        }
        else
        {
            lblDescriptionPlaveholder.isHidden = false
            lblDescriptionError.isHidden = true
        }
        
        
    }
    
    
    
    @objc func keyboardWillShow(notification:NSNotification){
        //give room at the bottom of the scroll view, so it doesn't cover up anything the user needs to tap
        var userInfo = notification.userInfo!
        var keyboardFrame:CGRect = (userInfo[UIResponder.keyboardFrameBeginUserInfoKey] as! NSValue).cgRectValue
        keyboardFrame = self.view.convert(keyboardFrame, from: nil)
        
        var contentInset:UIEdgeInsets = self.createBusinessScrollView.contentInset
        contentInset.bottom = keyboardFrame.size.height + 40
        createBusinessScrollView.contentInset = contentInset
    }
    
    @objc func keyboardWillHide(notification:NSNotification){
        let contentInset:UIEdgeInsets = UIEdgeInsets.zero
        createBusinessScrollView.contentInset = contentInset
    }
    
    
    //------------------------
    // MARK:Button Actions
    //-----------------------
   
    @IBAction func btnBackTUI(_ sender: UIButton)
    {
        navigationController?.popViewController(animated: true)
    }


//    @IBAction func btnEvent(_ sender: UIButton)
    
    
//    if  txtCompanyName.text == "" || (txtCompanyName.text! as NSString).trimmingCharacters(in: .whitespaces).isEmpty
    //
    //        {
    //            lblCompanyNameError.isHidden = false
    //        }
    //        else if txtDescription.text == "" || (txtDescription.text! as NSString).trimmingCharacters(in: .whitespaces).isEmpty
    //
    //        {
    //           lblDescriptionError.isHidden = false
    //        }
    //        else
    //        {
//
//    let obj = storyboard?.instantiateViewController(withIdentifier: "CreateBusinessVC") as! CreateBusinessVC
//
//
//    navigationController?.pushViewController(obj, animated: true)
//
    // contactUsAPI()
    // }
    
//}


    
    //------------------------
    // MARK:Web Services
    //-----------------------

   
}
