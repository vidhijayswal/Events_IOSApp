//
//  mainscreenVC.swift
//  Sultani Makutano
//
//  Created by vidhi jayswal on 06/06/19.
//  Copyright © 2019 vidhi jayswal. All rights reserved.
//

import UIKit

class mainscreenVC: UIViewController, UITableViewDataSource, UITableViewDelegate
{
    
    
    //-------------------
    // MARK: Outlets
    //-------------------
    
    
    @IBOutlet weak var containerView: UIView!
    
    @IBOutlet weak var btnHideMenu: UIButton!
    
    @IBOutlet weak var tblDrawerMenu: UITableView!
    
    @IBOutlet weak var sideView: UIView!
    
    @IBOutlet weak var sideViewWidth: NSLayoutConstraint!
    
    @IBOutlet weak var lblTitle: UILabel!
    
    @IBOutlet weak var btnEdit: UIButton!
    
    
    
    
    //-------------------
    // MARK: Identifiers
    //-------------------
    
    var isSideViewOpen : Bool = false
    
    var tableViewEventOrganizor = ["Events","Create Event","Businesses","Contact Us ","About Us","Profile","Logout"]
    
    var tableViewBusinessOwner = ["Events","Businesses","My Business","Contact Us","About Us","Profile","Logout"]
    
    var tableViewVisitor = ["Events","Businesses","QR Code","Favorites","Contact Us","About Us","Profile","Logout"]
    
    var VC = UIViewController()
    
    var type = Int()
    
    
    //-----------------------
    // MARK: View Life Cycle
    //-----------------------
    

    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        isSideViewOpen = false
        
        VC = storyboard?.instantiateViewController(withIdentifier: "EventsVC") as! EventsVC
        self.addChild(VC)
        VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
        self.containerView.addSubview(VC.view)
        VC.didMove(toParent: self)
        
        btnHideMenu.isEnabled = false

        
    }
    
    
    
    
    //--------------------------
    // MARK: Table View Methods
    //--------------------------
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        
       if UserDefaults.standard.integer(forKey: "eventorganizor") == type
       {
            return tableViewEventOrganizor.count
        }
       else if UserDefaults.standard.integer(forKey: "businessowner") == type
       {
            return tableViewBusinessOwner.count
       }
       else
       {
           return tableViewVisitor.count
        }
        
//        if UserDefaults.standard.bool(forKey: "eventorganizor")
//        {
//            return tableViewEventOrganizor.count
//        }
//        else if UserDefaults.standard.bool(forKey: "businessowner")
//        {
//            return tableViewBusinessOwner.count
//        }
//        else
//        {
//             return tableViewVisitor.count
//        }
//
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! TableViewCellSideView
        
        
        
        if UserDefaults.standard.integer(forKey: "eventorganizor") == type
        {
            cell.lblName.text = tableViewEventOrganizor[indexPath.row]
        }
        else if UserDefaults.standard.integer(forKey: "businessowner") == type
        {
            cell.lblName.text = tableViewBusinessOwner[indexPath.row]
        }
        else
        {
            cell.lblName.text = tableViewVisitor[indexPath.row]
        }
        
//        if UserDefaults.standard.bool(forKey: "eventorganizor")
//        {
//            cell.lblName.text = tableViewEventOrganizor[indexPath.row]
//
//        }
//        else if UserDefaults.standard.bool(forKey: "businessowner")
//        {
//            cell.lblName.text = tableViewBusinessOwner[indexPath.row]
//        }
//        else
//        {
//            cell.lblName.text = tableViewVisitor[indexPath.row]
//        }
//
        return cell
    }
    
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        var str = String()
        
        if UserDefaults.standard.integer(forKey: "eventorganizor") == type
        {
            str = tableViewEventOrganizor[indexPath.row]
            
            switch str
            {
                
            case "Events":
                
                lblTitle.text! = "Events"
                btnEdit.isHidden = true
                
                                VC = storyboard?.instantiateViewController(withIdentifier: "EventsVC") as! EventsVC
                                self.addChild(VC)
                                VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
                                self.containerView.addSubview(VC.view)
                                VC.didMove(toParent: self)
    
                
                isSideViewOpen = false
                
                UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions(), animations: { () -> Void in
                    self.sideViewWidth.constant = 0
                    self.view.layoutIfNeeded()
                }, completion: { (finished: Bool) -> Void in
                    
                })
                
                UIView.commitAnimations()
                btnHideMenu.isHidden = true
                
            case "Create Event":
                
                
                lblTitle.text! = "Create Event"
                btnEdit.isHidden = true
                
                
                                    VC = storyboard?.instantiateViewController(withIdentifier: "EventCreateVC") as! EventCreateVC
                                    self.addChild(VC)
                                    VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
                                    self.containerView.addSubview(VC.view)
                                    VC.didMove(toParent: self)
                
                
                isSideViewOpen = false
                
                UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions(), animations: { () -> Void in
                    self.sideViewWidth.constant = 0
                    self.view.layoutIfNeeded()
                }, completion: { (finished: Bool) -> Void in
                    
                })
                
                UIView.commitAnimations()
                btnHideMenu.isHidden = true
                
                
                
                
                
            case "Businesses":
                
                lblTitle.text! = "Businesses"
                btnEdit.isHidden = true
                
                
                
                                VC = storyboard?.instantiateViewController(withIdentifier: "businessVC") as! businessVC
                                self.addChild(VC)
                                VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
                                self.containerView.addSubview(VC.view)
                                VC.didMove(toParent: self)
                
                
                isSideViewOpen = false
                
                UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions(), animations: { () -> Void in
                    self.sideViewWidth.constant = 0
                    self.view.layoutIfNeeded()
                }, completion: { (finished: Bool) -> Void in
                    
                })
                
                UIView.commitAnimations()
                btnHideMenu.isHidden = true
                
                
                
            case "Contact Us ":
                
                lblTitle.text! = "Contact Us "
                btnEdit.isHidden = true
                
                
                
                                VC = storyboard?.instantiateViewController(withIdentifier: "ContactUsVC") as! ContactUsVC
                                self.addChild(VC)
                                VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
                                self.containerView.addSubview(VC.view)
                                VC.didMove(toParent: self)
                
                
                isSideViewOpen = false
                
                UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions(), animations: { () -> Void in
                    self.sideViewWidth.constant = 0
                    self.view.layoutIfNeeded()
                }, completion: { (finished: Bool) -> Void in
                    
                })
                
                UIView.commitAnimations()
                btnHideMenu.isHidden = true
                
                
                
            case "About Us":
                
                lblTitle.text! = "About Us"
                btnEdit.isHidden = true
                
                
                
                                VC = storyboard?.instantiateViewController(withIdentifier: "AboutUsVC") as! AboutUsVC
                                self.addChild(VC)
                                VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
                                self.containerView.addSubview(VC.view)
                                VC.didMove(toParent: self)
                
                
                isSideViewOpen = false
                
                UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions(), animations: { () -> Void in
                    self.sideViewWidth.constant = 0
                    self.view.layoutIfNeeded()
                }, completion: { (finished: Bool) -> Void in
                    
                })
                
                UIView.commitAnimations()
                btnHideMenu.isHidden = true
                
                
            case "Profile":
                
                lblTitle.text! = "Profile"
                
                btnEdit.isHidden = false
                
                
                                VC = storyboard?.instantiateViewController(withIdentifier: "ProfileVC") as! ProfileVC
                                self.addChild(VC)
                                VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
                                self.containerView.addSubview(VC.view)
                                VC.didMove(toParent: self)
                
                
                isSideViewOpen = false
                
                UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions(), animations: { () -> Void in
                    self.sideViewWidth.constant = 0
                    self.view.layoutIfNeeded()
                }, completion: { (finished: Bool) -> Void in
                    
                })
                
                UIView.commitAnimations()
                btnHideMenu.isHidden = true
                
                
                
            case "Logout":
                
                let alertController = UIAlertController(title: "Alert", message: "Are you sure you want to logout?", preferredStyle: .alert)
                
                // Create the actions
                let okAction = UIAlertAction(title: "Yes", style: UIAlertAction.Style.default)
                {
                    UIAlertAction in
                    NSLog("OK Pressed")
                    
                    UserDefaults.standard.set(0, forKey: "isUserLoggedIn")
                    
                                        let obj = self.storyboard?.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
                                        self.navigationController?.pushViewController(obj, animated: true)
                }
                
                let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel)
                {
                    UIAlertAction in
                    NSLog("Cancel Pressed")
                }
                
                // Add the actions
                alertController.addAction(okAction)
                alertController.addAction(cancelAction)
                
                // Present the controller
                self.present(alertController, animated: true, completion: nil)
                
                
            default:
                print("No Option Selected")
            }
        }
            
            
            
//["Events","Businesses","My Business","Contact Us ","About Us","Profile","Logout"]
            
    else if UserDefaults.standard.integer(forKey: "businessowner") == type
    {
            
            
        str = tableViewBusinessOwner[indexPath.row]
        
        switch str
        {
            
        case "Events":
            
            lblTitle.text! = "Events"
            btnEdit.isHidden = true
            
                            VC = storyboard?.instantiateViewController(withIdentifier: "EventsVC") as! EventsVC
                            self.addChild(VC)
                            VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
                            self.containerView.addSubview(VC.view)
                            VC.didMove(toParent: self)
            
            
            isSideViewOpen = false
            
            UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions(), animations: { () -> Void in
                self.sideViewWidth.constant = 0
                self.view.layoutIfNeeded()
            }, completion: { (finished: Bool) -> Void in
                
            })
            
            UIView.commitAnimations()
            btnHideMenu.isHidden = true
            
        case "Businesses":
            
            
            lblTitle.text! = "Businesses"
            btnEdit.isHidden = true
            
                                VC = storyboard?.instantiateViewController(withIdentifier: "businessVC") as! businessVC
                                self.addChild(VC)
                                VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
                                self.containerView.addSubview(VC.view)
                                VC.didMove(toParent: self)
            
            
            isSideViewOpen = false
            
            UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions(), animations: { () -> Void in
                self.sideViewWidth.constant = 0
                self.view.layoutIfNeeded()
            }, completion: { (finished: Bool) -> Void in
                
            })
            
            UIView.commitAnimations()
            btnHideMenu.isHidden = true
            
            
            
            
            
        case "My Business":
            
            lblTitle.text! = "My Business"
            btnEdit.isHidden = true
            
            
            
                            VC = storyboard?.instantiateViewController(withIdentifier: "MyBusinessVC") as! MyBusinessVC
                            self.addChild(VC)
                            VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
                            self.containerView.addSubview(VC.view)
                            VC.didMove(toParent: self)
            
            
            isSideViewOpen = false
            
            UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions(), animations: { () -> Void in
                self.sideViewWidth.constant = 0
                self.view.layoutIfNeeded()
            }, completion: { (finished: Bool) -> Void in
                
            })
            
            UIView.commitAnimations()
            btnHideMenu.isHidden = true
            
            
            
        case "Contact Us":
            
            lblTitle.text! = "Contact Us"
            btnEdit.isHidden = true
            
            
            
                            VC = storyboard?.instantiateViewController(withIdentifier: "ContactUsVC") as! ContactUsVC
                            self.addChild(VC)
                            VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
                            self.containerView.addSubview(VC.view)
                            VC.didMove(toParent: self)
            
            
            isSideViewOpen = false
            
            UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions(), animations: { () -> Void in
                self.sideViewWidth.constant = 0
                self.view.layoutIfNeeded()
            }, completion: { (finished: Bool) -> Void in
                
            })
            
            UIView.commitAnimations()
            btnHideMenu.isHidden = true
            
            
            
        case "About Us":
            
            lblTitle.text! = "About Us"
            btnEdit.isHidden = true
            
            
            
                            VC = storyboard?.instantiateViewController(withIdentifier: "AboutUsVC") as! AboutUsVC
                            self.addChild(VC)
                            VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
                            self.containerView.addSubview(VC.view)
                            VC.didMove(toParent: self)
            
            
            isSideViewOpen = false
            
            UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions(), animations: { () -> Void in
                self.sideViewWidth.constant = 0
                self.view.layoutIfNeeded()
            }, completion: { (finished: Bool) -> Void in
                
            })
            
            UIView.commitAnimations()
            btnHideMenu.isHidden = true
            
            
        case "Profile":
            
            lblTitle.text! = "Profile"
            btnEdit.isHidden = false
            
            
                            VC = storyboard?.instantiateViewController(withIdentifier: "ProfileVC") as! ProfileVC
                            self.addChild(VC)
                            VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
                            self.containerView.addSubview(VC.view)
                            VC.didMove(toParent: self)
            
            
            isSideViewOpen = false
            
            UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions(), animations: { () -> Void in
                self.sideViewWidth.constant = 0
                self.view.layoutIfNeeded()
            }, completion: { (finished: Bool) -> Void in
                
            })
            
            UIView.commitAnimations()
            btnHideMenu.isHidden = true
            
            
        case "Logout":
            
            let alertController = UIAlertController(title: "Alert", message: "Are you sure you want to logout?", preferredStyle: .alert)
            
            // Create the actions
            let okAction = UIAlertAction(title: "Yes", style: UIAlertAction.Style.default)
            {
                UIAlertAction in
                NSLog("OK Pressed")
                
                UserDefaults.standard.set(0, forKey: "isUserLoggedIn")
                
                let obj = self.storyboard?.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
                self.navigationController?.pushViewController(obj, animated: true)
            }
            
            let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel)
            {
                UIAlertAction in
                NSLog("Cancel Pressed")
            }
            
            // Add the actions
            alertController.addAction(okAction)
            alertController.addAction(cancelAction)
            
            // Present the controller
            self.present(alertController, animated: true, completion: nil)
            
            
        default:
            print("No Option Selected")
        }
            
    }
            
            
            
//  tableViewVisitor = ["Events","Businesses","QR Code","Favorites","Contact Us ","About Us","Profile","Logout"]
        
            
        else
        {
            
            str = tableViewVisitor[indexPath.row]
            
            switch str
            {
                
                
            case "Events":
                
                lblTitle.text! = "Events"
                btnEdit.isHidden = true
                
                
                                VC = storyboard?.instantiateViewController(withIdentifier: "EventsVC") as! EventsVC
                                self.addChild(VC)
                                VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
                                self.containerView.addSubview(VC.view)
                                VC.didMove(toParent: self)
                
                
                isSideViewOpen = false
                
                UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions(), animations: { () -> Void in
                    self.sideViewWidth.constant = 0
                    self.view.layoutIfNeeded()
                }, completion: { (finished: Bool) -> Void in
                    
                })
                
                UIView.commitAnimations()
                btnHideMenu.isHidden = true
                
                
                
            case "Businesses":
                
                lblTitle.text! = "Businesses"
                btnEdit.isHidden = true
    
                
                                VC = storyboard?.instantiateViewController(withIdentifier: "businessVC") as! businessVC
                                self.addChild(VC)
                                VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
                                self.containerView.addSubview(VC.view)
                                VC.didMove(toParent: self)
                
                
                isSideViewOpen = false
                
                UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions(), animations: { () -> Void in
                    self.sideViewWidth.constant = 0
                    self.view.layoutIfNeeded()
                }, completion: { (finished: Bool) -> Void in
                    
                })
                
                UIView.commitAnimations()
                btnHideMenu.isHidden = true
                
                
            case "QR Code":
                
                lblTitle.text! = "QR Code"
                btnEdit.isHidden = true
                
        
                                VC = storyboard?.instantiateViewController(withIdentifier: "QRCodeVC") as! QRCodeVC
                
                
                                self.addChild(VC)
                                VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
                                self.containerView.addSubview(VC.view)
                                VC.didMove(toParent: self)
                
                
                isSideViewOpen = false
                
                UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions(), animations: { () -> Void in
                    self.sideViewWidth.constant = 0
                    self.view.layoutIfNeeded()
                }, completion: { (finished: Bool) -> Void in
                    
                })
                
                UIView.commitAnimations()
                btnHideMenu.isHidden = true
                
                
            case "Favorites":
                
                lblTitle.text! = "Favorites"
                btnEdit.isHidden = true
                
               
                
                //                VC = storyboard?.instantiateViewController(withIdentifier: "ContactUsVC") as! ContactUsVC
                //                self.addChild(VC)
                //                VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
                //                self.containerView.addSubview(VC.view)
                //                VC.didMove(toParent: self)
                
                
                isSideViewOpen = false
                
                UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions(), animations: { () -> Void in
                    self.sideViewWidth.constant = 0
                    self.view.layoutIfNeeded()
                }, completion: { (finished: Bool) -> Void in
                    
                })
                
                UIView.commitAnimations()
                btnHideMenu.isHidden = true
                
                
                
                
                
            case "Contact Us":
                
                lblTitle.text! = "Contact Us"
                btnEdit.isHidden = true
                
                
                
                                VC = storyboard?.instantiateViewController(withIdentifier: "ContactUsVC") as! ContactUsVC
                                self.addChild(VC)
                                VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
                                self.containerView.addSubview(VC.view)
                                VC.didMove(toParent: self)
                
                
                isSideViewOpen = false
                
                UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions(), animations: { () -> Void in
                    self.sideViewWidth.constant = 0
                    self.view.layoutIfNeeded()
                }, completion: { (finished: Bool) -> Void in
                    
                })
                
                UIView.commitAnimations()
                btnHideMenu.isHidden = true
                
                
                
            case "About Us":
                
                lblTitle.text! = "About Us"
                btnEdit.isHidden = true
                
                
                
                                VC = storyboard?.instantiateViewController(withIdentifier: "AboutUsVC") as! AboutUsVC
                                self.addChild(VC)
                                VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
                                self.containerView.addSubview(VC.view)
                                VC.didMove(toParent: self)
                
                
                isSideViewOpen = false
                
                UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions(), animations: { () -> Void in
                    self.sideViewWidth.constant = 0
                    self.view.layoutIfNeeded()
                }, completion: { (finished: Bool) -> Void in
                    
                })
                
                UIView.commitAnimations()
                btnHideMenu.isHidden = true
                
                
                
            case "Profile":
                
                lblTitle.text! = "Profile"
                btnEdit.isHidden = false
                
                
                
                                VC = storyboard?.instantiateViewController(withIdentifier: "ProfileVC") as! ProfileVC
                                self.addChild(VC)
                                VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
                                self.containerView.addSubview(VC.view)
                                VC.didMove(toParent: self)
                
                
                isSideViewOpen = false
                
                UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions(), animations: { () -> Void in
                    self.sideViewWidth.constant = 0
                    self.view.layoutIfNeeded()
                }, completion: { (finished: Bool) -> Void in
                    
                })
                
                UIView.commitAnimations()
                btnHideMenu.isHidden = true
                
                
                
                
            case "Logout":
                
                let alertController = UIAlertController(title: "Alert", message: "Are you sure you want to logout?", preferredStyle: .alert)
                
                // Create the actions
                let okAction = UIAlertAction(title: "Yes", style: UIAlertAction.Style.default)
                {
                    UIAlertAction in
                    NSLog("OK Pressed")
                    
                    UserDefaults.standard.set(0, forKey: "isUserLoggedIn")
                    
                    let obj = self.storyboard?.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
                    self.navigationController?.pushViewController(obj, animated: true)
                }
                
                let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel)
                {
                    UIAlertAction in
                    NSLog("Cancel Pressed")
                }
                
                // Add the actions
                alertController.addAction(okAction)
                alertController.addAction(cancelAction)
                
                // Present the controller
                self.present(alertController, animated: true, completion: nil)
                
            default:
                print("No Option Selected")
            }
            
            
        }
        
        
    }
    
    
    
    
    
    
    
    
    
    
    //--------------------------
    //MARK: Button Action
    //--------------------------
    
    
    @IBAction func btnMenu(_ sender: UIButton)
    {
        
        self.view.bringSubviewToFront(sideView)
        
        if !isSideViewOpen
        {
            isSideViewOpen = true
            
            btnHideMenu.isEnabled = true
            
            UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseIn, animations: { () -> Void in
                self.sideViewWidth.constant = self.view.frame.width * 0.7
                self.view.layoutIfNeeded()
            }, completion: { (finished: Bool) -> Void in
                
            })
            
            UIView.commitAnimations()
            btnHideMenu.isHidden = false
            
            btnHideMenu.backgroundColor = UIColor(red: 200.0/255.0, green: 200.0/255.0, blue: 200.0/255.0, alpha:0.3)
            
        }
    }
    
    
    
    
    @IBAction func btnHide(_ sender: UIButton)
    {
        
        isSideViewOpen = false
        
        UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions(), animations: { () -> Void in
            self.sideViewWidth.constant = 0
            self.view.layoutIfNeeded()
        }, completion: { (finished: Bool) -> Void in
            
        })
        
        UIView.commitAnimations()
        btnHideMenu.isHidden = true
    }
    
    
    
    
    
    
    

}
