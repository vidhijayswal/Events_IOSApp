//
//  PastEventsVC.swift
//  Sultani Makutano
//
//  Created by vidhi jayswal on 08/06/19.
//  Copyright © 2019 vidhi jayswal. All rights reserved.
//

import UIKit

class PastEventsVC: UIViewController, UITableViewDataSource, UITableViewDelegate
{
    
    
    
    //-------------------
    // MARK: Outlets
    //-------------------
    
    @IBOutlet weak var tblView: UITableView!
    
    //-------------------
    // MARK: Identifiers
    //-------------------
    
    
    
    
    var arrayimage = ["icon_event","icon_event","icon_event","icon_event","icon_event","icon_event","icon_event","icon_event","icon_event","icon_event"]
    
    
    
    
    //------------------------
    // MARK: View Life Cycle
    //------------------------
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.tblView.rowHeight = 250.0
        
        
    }
    
    
    
    
    //--------------------------
    // MARK: Table View Methods
    //--------------------------
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return arrayimage.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell:TableViewPastEventsCell = tableView.dequeueReusableCell(withIdentifier: "cell") as! TableViewPastEventsCell
        
        return cell
        
}


//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
//    {
//        let obj = storyboard?.instantiateViewController(withIdentifier: "EventDetailVC") as! EventDetailVC
//
//        navigationController?.pushViewController(obj, animated: true)
//    }
    
    
    
    
    
    
    
    //-----------------------------
    // MARK: User Defined Functions
    //-----------------------------
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    //-----------------------
    // MARK: Button Action
    //-----------------------
    
    
    @IBAction func btnEventDetail(_ sender: UIButton)
    {
        let obj = storyboard?.instantiateViewController(withIdentifier: "EventDetailVC") as! EventDetailVC
        
        navigationController?.pushViewController(obj, animated: true)
    }
    
    
    
    
    
    
    
    
    
    
    //--------------------
    // MARK: Web Service
    //--------------------
    
    
    
}
