//
//  MyBusinessVC.swift
//  Sultani Mukhtano
//
//  Created by sanjay bhatia on 08/06/19.
//  Copyright © 2019 sanjay bhatia. All rights reserved.
//

import UIKit

class MyBusinessVC: UIViewController,UITextFieldDelegate {

    //-----------------------
    //MARK:Outlets
    //-----------------------
    
    @IBOutlet weak var MyBusinessScrollView: UIScrollView!
    
    @IBOutlet weak var lblNamePalceholder: UILabel!
    
    @IBOutlet weak var txtName: UITextField!
    
    @IBOutlet weak var lblNameError: UILabel!
    
    @IBOutlet weak var lblEmailPlaceholder: UILabel!
    
    @IBOutlet weak var txtEmail: UITextField!
    
    @IBOutlet weak var lblEmailError: UILabel!
    
    @IBOutlet weak var lblPhonePlaceholder: UILabel!
    
    @IBOutlet weak var txtPhone: UITextField!
    
    @IBOutlet weak var lblPhoneError: UILabel!
    
    @IBOutlet weak var lblAddressPlaceholder: UILabel!
    
    @IBOutlet weak var txtViewAddress: UITextView!
    
    @IBOutlet weak var lblAddressError: UILabel!
    
    @IBOutlet weak var lblCompanyNamePaceholder: UILabel!
    
    @IBOutlet weak var txtCompanyName: UITextField!
    
    @IBOutlet weak var lblCompanyNameError: UILabel!
    
    @IBOutlet weak var lblCompanyDescriptionPlaceholder: UILabel!
    
    @IBOutlet weak var txtViewCompanyDescription: UITextView!
    
    @IBOutlet weak var lblCompanyDescriptionError: UILabel!
    
   
    
    @IBOutlet weak var imgAdd: UIImageView!
    
    
    //-------------------------
    // MARK: Identifiers
    //-------------------------
    
    
    
    //----------------------------
    //MARK: View Life Cycle
    //----------------------------
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        lblNamePalceholder.isHidden = true
        
        lblNameError.isHidden = true
        
        lblEmailPlaceholder.isHidden = true
        
        lblEmailError.isHidden = true
        
        lblPhonePlaceholder.isHidden = true
        
        lblPhoneError.isHidden = true
        
        lblAddressPlaceholder.isHidden = true
        
        lblAddressError.isHidden = true
        
        lblCompanyNamePaceholder.isHidden = true
        
        lblCompanyNameError.isHidden = true
        
        lblCompanyDescriptionPlaceholder.isHidden = true
        
        lblCompanyDescriptionError.isHidden = true
        
       
//-----------------------------------------------------------
        
        
        txtName.delegate = self
        
        txtEmail.delegate = self
        
        txtPhone.delegate = self
        
       // txtViewAddress.delegate = self
        
        txtCompanyName.delegate = self
        
        //txtViewCompanyDescription.delegate = self
        
     
//-----------------------------------------------------------
        
        
        txtName.addTarget(self, action: #selector(txtFullNameValueChange), for: .editingChanged)
        
        txtEmail.addTarget(self, action: #selector(txtEmailValueChange), for: .editingChanged)
        
        txtPhone.addTarget(self, action: #selector(txtPhoneValueChange), for: .editingChanged)
        
       // txtAddress.addTarget(self, action: #selector(txtAddressValueChange), for: .editingChanged)
        
        txtCompanyName.addTarget(self, action: #selector(txtCompanyNameValueChange), for: .editingChanged)
        
       // txtCompanyDescription.addTarget(self, action: #selector(txtCompanyDescriptionValueChange), for: .editingChanged)
        
     
//-----------------------------------------------------------
        
        
        txtName.attributedPlaceholder = NSMutableAttributedString(string: "Enter Full Name",attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray])
        
        txtEmail.attributedPlaceholder = NSMutableAttributedString(string: "Enter Email ",attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray])
        
        txtPhone.attributedPlaceholder = NSMutableAttributedString(string: "Enter Phone",attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray])
        
       // txtAddress.attributedPlaceholder = NSMutableAttributedString(string: "Enter Address",attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray])
        
        
        
        txtCompanyName.attributedPlaceholder = NSMutableAttributedString(string: "Enter Company Name",attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray])
        
      //  txtCompanyDescription.attributedPlaceholder = NSMutableAttributedString(string: "Enter Company Description",attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray])
        
      
    
    }
    
    
    //----------------------------
    //MARK: Delegate Methods
    //----------------------------
    
    
    
    
    
    
    //--------------------------------
    //MARK: User Defined Functions
    //--------------------------------
    
    
    @objc func txtFullNameValueChange()
    {
        if txtName.text == ""
        {
            lblNamePalceholder.isHidden = true
            lblNameError.isHidden = false
        }
        else
        {
            lblNamePalceholder.isHidden = false
            lblNameError.isHidden = true
        }
    }
    
    @objc func txtEmailValueChange()
    {
        if txtEmail.text == ""
        {
            lblEmailPlaceholder.isHidden = true
            lblEmailError.isHidden = false
        }
        else
        {
            lblEmailPlaceholder.isHidden = false
            lblEmailError.isHidden = true
        }
        
        
    }
    @objc func txtPhoneValueChange()
    {
        if txtPhone.text == ""
        {
            lblPhonePlaceholder.isHidden = true
            lblPhoneError.isHidden = false
        }
        else
        {
            lblPhonePlaceholder.isHidden = false
            lblPhoneError.isHidden = true
        }
    }
    
    @objc func txtAddressValueChange()
    {
        if txtViewAddress.text == ""
        {
            lblAddressPlaceholder.isHidden = true
            lblAddressError.isHidden = false
        }
        else
        {
            lblAddressPlaceholder.isHidden = false
            lblAddressError.isHidden = true
        }
    }
    
    
    @objc func txtCompanyNameValueChange()
    {
        if txtCompanyName.text == ""
        {
            lblCompanyNamePaceholder.isHidden = true
            lblCompanyNameError.isHidden = false
        }
        else
        {
            lblCompanyNamePaceholder.isHidden = false
            lblCompanyNameError.isHidden = true
        }
    }
    
    @objc func txtCompanyDescriptionValueChange()
    {
        if txtViewCompanyDescription.text == ""
        {
            lblCompanyDescriptionPlaceholder.isHidden = true
            lblCompanyDescriptionError.isHidden = false
        }
        else
        {
            lblCompanyDescriptionPlaceholder.isHidden = false
            lblCompanyDescriptionError.isHidden = true
        }
    }
    
    
   
    
//-----------------------------------------------------------
    
    @objc func keyboardWillShow(notification:NSNotification)
    
    {
        //give room at the bottom of the scroll view, so it doesn't cover up anything the user needs to tap
        var userInfo = notification.userInfo!
        var keyboardFrame:CGRect = (userInfo[UIResponder.keyboardFrameBeginUserInfoKey] as! NSValue).cgRectValue
        keyboardFrame = self.view.convert(keyboardFrame, from: nil)
        
        var contentInset:UIEdgeInsets = self.MyBusinessScrollView.contentInset
        contentInset.bottom = keyboardFrame.size.height + 40
        MyBusinessScrollView.contentInset = contentInset
    }
    
    @objc func keyboardWillHide(notification:NSNotification)
    
    {
        let contentInset:UIEdgeInsets = UIEdgeInsets.zero
        MyBusinessScrollView.contentInset = contentInset
    }
    
    
    //------------------------
    // MARK:Button Actions
    //-----------------------
    
    
    //------------------------
    // MARK:Web Services
    //-----------------------
    


}
