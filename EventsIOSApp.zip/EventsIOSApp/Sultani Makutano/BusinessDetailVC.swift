//
//  BusinessDetailVC.swift
//  Sultani Mukhtano
//
//  Created by sanjay bhatia on 07/06/19.
//  Copyright © 2019 sanjay bhatia. All rights reserved.
//

import UIKit

class BusinessDetailVC: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {
  
    

    
    
    //-----------------------
    //MARK:Outlets
    //-----------------------
    
    @IBOutlet weak var headerview: UIView!
    
    @IBOutlet weak var colViewBusinessDetail: UICollectionView!
    
    @IBOutlet weak var scrollView: UIScrollView!
    
    @IBOutlet weak var imgBusinessLogo: UIImageView!
    
    @IBOutlet weak var lblBusinessName: UILabel!
    
    @IBOutlet weak var lblOwnerName: UILabel!
    
    @IBOutlet weak var lblDescription: UILabel!
    
    @IBOutlet weak var lblEmail: UIView!
    
    @IBOutlet weak var lblPhone: UIView!
    
    @IBOutlet weak var lblAddress: UIView!
   
    
    //-------------------------
    // MARK: Identifiers
    //-------------------------
    
    var imgArryBussiness =  [#imageLiteral(resourceName: "property"),#imageLiteral(resourceName: "icon_logo"),#imageLiteral(resourceName: "Icon_logo_main")]
    
    
    //----------------------------
    //MARK: View Life Cycle
    //----------------------------
    
    
    
    
  
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    //----------------------------
    //MARK: Delegate Methods
    //----------------------------
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return imgArryBussiness.count
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
       let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ColCellBusinessDetail", for: indexPath) as! ColCellBusinessDetail
        
        cell.imgBusiness.image = imgArryBussiness[indexPath.row]
        
        
        
        return cell
        
    }
    
    
    
    //--------------------------------
    //MARK: User Defined Functions
    //--------------------------------
    
    
    
    //------------------------
    // MARK:Button Actions
    //-----------------------
    
    @IBAction func btnBackTUI(_ sender: UIButton)
    
    {
        navigationController?.popViewController(animated: true)
    }
    
    //------------------------
    // MARK:Web Services
    //-----------------------


}
