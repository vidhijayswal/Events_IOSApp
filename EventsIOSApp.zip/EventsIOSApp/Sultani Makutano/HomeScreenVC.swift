//
//  HomeScreenVC.swift
//  new_ios_application
//
//  Created by vidhi jayswal on 03/04/19.
//  Copyright © 2019 vidhi jayswal. All rights reserved.
//

import UIKit


class HomeScreenVC: UIViewController, UITableViewDataSource, UITableViewDelegate
{
    
    //-------------------
    // MARK: Outlets
    //-------------------
    
   
    @IBOutlet weak var containerView: UIView!
    
    @IBOutlet weak var btnHideMenu: UIButton!
    
   @IBOutlet weak var tblDrawerMenu: UITableView!
    
    @IBOutlet weak var sideview: UIView!
    
    @IBOutlet weak var sideViewWIdth: NSLayoutConstraint!
    
    @IBOutlet weak var lblTitle: UILabel!
    
    @IBOutlet weak var searchView: UIView!
    
    @IBOutlet weak var lblusername: UILabel!
    
    
    
    //-----------------------
    //MARK: Identifiers
    //-----------------------
    
    
    var isSideViewOpen : Bool = false
    
    var tableViewData = ["Home","My Account","My Wishlist","Categories","Notification","Contact Us","About Asfericollection","Logout"]
    
    var tableviewDatanotloggedIn = ["Log In","Home","Categories","Notification","Contact Us","About Asfericollection"]
    
    var VC = UIViewController()
    
//    var imgarray = [#imageLiteral(resourceName: "icon_home_black"),#imageLiteral(resourceName: "icon_myaccount_black"),#imageLiteral(resourceName: "icon_mywishlist_black"),#imageLiteral(resourceName: "icon_categories_black"),#imageLiteral(resourceName: "icon_notification_black"),#imageLiteral(resourceName: "icon_contactus_black"),#imageLiteral(resourceName: "icon_about_black"),#imageLiteral(resourceName: "icon_logout_black")]
//
//    var imgarraynotloggesin = [#imageLiteral(resourceName: "icon_login_black"),#imageLiteral(resourceName: "icon_home_black"),#imageLiteral(resourceName: "icon_categories_black"),#imageLiteral(resourceName: "icon_notification_black"),#imageLiteral(resourceName: "icon_contactus_black"),#imageLiteral(resourceName: "icon_about_black")]
    
    
        //-------------------------------
        // MARK: View Life Cycle
        //-------------------------------
        
    override func viewDidLoad()
        {
            
            super.viewDidLoad()
            
            isSideViewOpen = false
            
//            VC = storyboard?.instantiateViewController(withIdentifier: "ProductsScreenVC") as! ProductsScreenVC
//            self.addChild(VC)
//            VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
//            self.containerView.addSubview(VC.view)
//            VC.didMove(toParent: self)
            
        }
    
    
    
    //--------------------------
    //MARK: Tableview methods
    //--------------------------
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if UserDefaults.standard.bool(forKey: "isUserLoggedIn")
        {
            return tableViewData.count
        }
        else
        {
            return tableviewDatanotloggedIn.count
        }
        
    }
    
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
        
        if UserDefaults.standard.bool(forKey: "isUserLoggedIn")
        {
            cell.lblName.text = tableViewData[indexPath.row]
            //cell.img.image = imgarray[indexPath.row]
        }
        else
        {
            cell.lblName.text = tableviewDatanotloggedIn[indexPath.row]
            
           // cell.img.image = imgarraynotloggesin[indexPath.row]
        }
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        var str = String()
        
        if UserDefaults.standard.bool(forKey: "isUserLoggedIn")
        {
            str = tableViewData[indexPath.row]
            
            switch str
            {
                
            case "Home":
                
                lblTitle.text! = "Home"
                
                searchView.isHidden = false
                
//                VC = storyboard?.instantiateViewController(withIdentifier: "ProductsScreenVC") as! ProductsScreenVC
//                self.addChild(VC)
//                VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
//                self.containerView.addSubview(VC.view)
//                VC.didMove(toParent: self)
//
                
                isSideViewOpen = false
                
                UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions(), animations: { () -> Void in
                    self.sideViewWIdth.constant = 0
                    self.view.layoutIfNeeded()
                }, completion: { (finished: Bool) -> Void in
                    
                })
                
                UIView.commitAnimations()
                btnHideMenu.isHidden = true
                
            case "My Account":
                
                
                    lblTitle.text! = "My Account"
                    
                    searchView.isHidden = true
                    
////                    VC = storyboard?.instantiateViewController(withIdentifier: "MyAccount") as! MyAccount
//                    self.addChild(VC)
//                    VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
//                    self.containerView.addSubview(VC.view)
//                    VC.didMove(toParent: self)
                    
                    
                    isSideViewOpen = false
                    
                    UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions(), animations: { () -> Void in
                        self.sideViewWIdth.constant = 0
                        self.view.layoutIfNeeded()
                    }, completion: { (finished: Bool) -> Void in
                        
                    })
                    
                    UIView.commitAnimations()
                    btnHideMenu.isHidden = true

                
                
                
                
            case "My Wishlist":
                
                lblTitle.text! = "My Wishlist"
                
                searchView.isHidden = false
                
////                VC = storyboard?.instantiateViewController(withIdentifier: "MyWishlistVC") as! MyWishlistVC
//                self.addChild(VC)
//                VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
//                self.containerView.addSubview(VC.view)
//                VC.didMove(toParent: self)
                
                
                isSideViewOpen = false
                
                UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions(), animations: { () -> Void in
                    self.sideViewWIdth.constant = 0
                    self.view.layoutIfNeeded()
                }, completion: { (finished: Bool) -> Void in
                    
                })
                
                UIView.commitAnimations()
                btnHideMenu.isHidden = true
                
                
                
            case "Categories":
                
                lblTitle.text! = "Categories"
                
                searchView.isHidden = false
                
//                VC = storyboard?.instantiateViewController(withIdentifier: "categoriesVC") as! categoriesVC
//                self.addChild(VC)
//                VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
//                self.containerView.addSubview(VC.view)
//                VC.didMove(toParent: self)
                
                
                isSideViewOpen = false
                
                UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions(), animations: { () -> Void in
                    self.sideViewWIdth.constant = 0
                    self.view.layoutIfNeeded()
                }, completion: { (finished: Bool) -> Void in
                    
                })
                
                UIView.commitAnimations()
                btnHideMenu.isHidden = true
                
                
                
            case "Notification":
                
                lblTitle.text! = "Notification"
                
                searchView.isHidden = true
                
//                VC = storyboard?.instantiateViewController(withIdentifier: "notificationVC") as! notificationVC
//                self.addChild(VC)
//                VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
//                self.containerView.addSubview(VC.view)
//                VC.didMove(toParent: self)
                
                
                isSideViewOpen = false
                
                UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions(), animations: { () -> Void in
                    self.sideViewWIdth.constant = 0
                    self.view.layoutIfNeeded()
                }, completion: { (finished: Bool) -> Void in
                    
                })
                
                UIView.commitAnimations()
                btnHideMenu.isHidden = true
                
                
            case "About Asfericollection":
                
                lblTitle.text! = "About Asfericollection"
                
                searchView.isHidden = true
//                VC = storyboard?.instantiateViewController(withIdentifier: "AboutAsfericollectionVC") as! AboutAsfericollectionVC
//                self.addChild(VC)
//                VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
//                self.containerView.addSubview(VC.view)
//                VC.didMove(toParent: self)
//
                
                isSideViewOpen = false
                
                UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions(), animations: { () -> Void in
                    self.sideViewWIdth.constant = 0
                    self.view.layoutIfNeeded()
                }, completion: { (finished: Bool) -> Void in
                    
                })
                
                UIView.commitAnimations()
                btnHideMenu.isHidden = true
                
                
            case "Contact Us":
                
                lblTitle.text! = "Contact Us"
                
                searchView.isHidden = true
                
//                VC = storyboard?.instantiateViewController(withIdentifier: "ContactUsVC") as! ContactUsVC
//                self.addChild(VC)
//                VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
//                self.containerView.addSubview(VC.view)
//                VC.didMove(toParent: self)
                
                
                isSideViewOpen = false
                
                UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions(), animations: { () -> Void in
                    self.sideViewWIdth.constant = 0
                    self.view.layoutIfNeeded()
                }, completion: { (finished: Bool) -> Void in
                    
                })
                
                UIView.commitAnimations()
                btnHideMenu.isHidden = true
                
                
                
                
            case "Logout":
                
                let alertController = UIAlertController(title: "Alert", message: "Are you sure you want to logout?", preferredStyle: .alert)
                
                // Create the actions
                let okAction = UIAlertAction(title: "Yes", style: UIAlertAction.Style.default)
                {
                    UIAlertAction in
                    NSLog("OK Pressed")
                    
                    UserDefaults.standard.set(0, forKey: "isUserLoggedIn")
                    
//                    let obj = self.storyboard?.instantiateViewController(withIdentifier: "loginScreenVC") as! loginScreenVC
//                    self.navigationController?.pushViewController(obj, animated: true)
                }
                
                let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel)
                {
                    UIAlertAction in
                    NSLog("Cancel Pressed")
                }
                
                // Add the actions
                alertController.addAction(okAction)
                alertController.addAction(cancelAction)
                
                // Present the controller
                self.present(alertController, animated: true, completion: nil)
                
                
            default:
                print("No Option Selected")
            }
        }
        
        else
        {
            
            str = tableviewDatanotloggedIn[indexPath.row]
            
            switch str
            {
                
                
            case "Log In":
                
                let obj = storyboard?.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC

                navigationController?.pushViewController(obj, animated: true)
                
                
            case "Home":
                
                lblTitle.text! = "Home"
                
                searchView.isHidden = false
                
//                VC = storyboard?.instantiateViewController(withIdentifier: "ProductsScreenVC") as! ProductsScreenVC
//                self.addChild(VC)
//                VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
//                self.containerView.addSubview(VC.view)
//                VC.didMove(toParent: self)
                
                
                isSideViewOpen = false
                
                UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions(), animations: { () -> Void in
                    self.sideViewWIdth.constant = 0
                    self.view.layoutIfNeeded()
                }, completion: { (finished: Bool) -> Void in
                    
                })
                
                UIView.commitAnimations()
                btnHideMenu.isHidden = true
                
                
                
            case "Categories":
                
                lblTitle.text! = "Categories"
                
                searchView.isHidden = false
                
//                VC = storyboard?.instantiateViewController(withIdentifier: "categoriesVC") as! categoriesVC
//                self.addChild(VC)
//                VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
//                self.containerView.addSubview(VC.view)
//                VC.didMove(toParent: self)
                
                
                isSideViewOpen = false
                
                UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions(), animations: { () -> Void in
                    self.sideViewWIdth.constant = 0
                    self.view.layoutIfNeeded()
                }, completion: { (finished: Bool) -> Void in
                    
                })
                
                UIView.commitAnimations()
                btnHideMenu.isHidden = true
                
                
            case "About Asfericollection":
                
                lblTitle.text! = "About Asfericollection"
                
                searchView.isHidden = true
//                VC = storyboard?.instantiateViewController(withIdentifier: "AboutAsfericollectionVC") as! AboutAsfericollectionVC
//                self.addChild(VC)
//                VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
//                self.containerView.addSubview(VC.view)
//                VC.didMove(toParent: self)
                
                
                isSideViewOpen = false
                
                UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions(), animations: { () -> Void in
                    self.sideViewWIdth.constant = 0
                    self.view.layoutIfNeeded()
                }, completion: { (finished: Bool) -> Void in
                    
                })
                
                UIView.commitAnimations()
                btnHideMenu.isHidden = true
                
                
            case "Contact Us":
                
                lblTitle.text! = "Contact Us"
                
                searchView.isHidden = true
                
//                VC = storyboard?.instantiateViewController(withIdentifier: "ContactUsVC") as! ContactUsVC
//                self.addChild(VC)
//                VC.view.frame = CGRect.init(x: 0, y: 0, width: self.containerView.frame.size.width, height: self.containerView.frame.size.height)
//                self.containerView.addSubview(VC.view)
//                VC.didMove(toParent: self)
                
                
                isSideViewOpen = false
                
                UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions(), animations: { () -> Void in
                    self.sideViewWIdth.constant = 0
                    self.view.layoutIfNeeded()
                }, completion: { (finished: Bool) -> Void in
                    
                })
                
                UIView.commitAnimations()
                btnHideMenu.isHidden = true
                
            default:
                print("No Option Selected")
            }
            
            
        }
        
        
    }
    
    
    //--------------------------
    //MARK: Button Action
    //--------------------------
    
    
    @IBAction func btnMenu(_ sender: UIButton)
    {
        
        self.view.bringSubviewToFront(sideview)
        
        if !isSideViewOpen
        {
            isSideViewOpen = true
            
            UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseIn, animations: { () -> Void in
                self.sideViewWIdth.constant = self.view.frame.width * 0.7
                self.view.layoutIfNeeded()
            }, completion: { (finished: Bool) -> Void in
                
            })
            
            UIView.commitAnimations()
            btnHideMenu.isHidden = false
            
            btnHideMenu.backgroundColor = UIColor(red: 200.0/255.0, green: 200.0/255.0, blue: 200.0/255.0, alpha:0.3)
            
        }
    }
    
    
    
    
    @IBAction func btnHide(_ sender: UIButton)
    {
        
        isSideViewOpen = false
        
        UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions(), animations: { () -> Void in
            self.sideViewWIdth.constant = 0
            self.view.layoutIfNeeded()
        }, completion: { (finished: Bool) -> Void in
            
        })
        
        UIView.commitAnimations()
        btnHideMenu.isHidden = true
    }
    
    
    @IBAction func btnSearch(_ sender: UIButton)
    {
//        let obj = storyboard?.instantiateViewController(withIdentifier: "SearchVC") as! SearchVC
//
//        navigationController?.pushViewController(obj, animated: true)
    }
    
    
    
}
