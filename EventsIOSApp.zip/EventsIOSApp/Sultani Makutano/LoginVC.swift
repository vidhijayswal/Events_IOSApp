//
//  LoginVC.swift
//  Sultani Makutano
//
//  Created by vidhi jayswal on 05/06/19.
//  Copyright © 2019 vidhi jayswal. All rights reserved.
//

import UIKit

class LoginVC: UIViewController, UITextFieldDelegate
{
    
    
    //-------------------
    // MARK: Outlets
    //-------------------
    
    
    @IBOutlet weak var txtUsername: UITextField!
    
    @IBOutlet weak var txtPassword: UITextField!
    
    @IBOutlet weak var lblUsername: UILabel!
    
    @IBOutlet weak var lblUsernameError: UILabel!
    
    @IBOutlet weak var lblPassword: UILabel!
    
    @IBOutlet weak var lblPasswordError: UILabel!
    
    @IBOutlet weak var scrollView: UIScrollView!
    
    
    
    
    //-------------------
    // MARK: Identifiers
    //-------------------
    
    
    
    
    
    
    
    
    
    
    //-------------------
    // MARK: View Life Cycle
    //-------------------
    


    override func viewDidLoad()
    {
        super.viewDidLoad()

        
        
        lblUsernameError.isHidden = true
        lblPasswordError.isHidden = true
        
        
        lblUsername.isHidden = true
        lblPassword.isHidden = true
        
        
        txtUsername.delegate = self
        txtPassword.delegate = self
        
        
        
        txtUsername.addTarget(self, action: #selector(txtUserNameValueChanged), for: .editingChanged)
        txtPassword.addTarget(self, action: #selector(txtPasswordValueChanged), for: .editingChanged)
        
        
        self.hideKeyboardTappedArround()
        

        
    }
    
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        registerKeyboardNotifications()
    }
    
    
    //------------------------------
    // MARK: Delegate Methods
    //------------------------------
    
    @objc func txtUserNameValueChanged()
    {
        if txtUsername.text == ""
        {
            lblUsername.isHidden = true
            lblUsernameError.isHidden = false
        }
        else
        {
            lblUsername.isHidden = false
            lblUsernameError.isHidden = true
        }
    }
    
    
    @objc func txtPasswordValueChanged()
    {
        if txtPassword.text == ""
        {
            lblPassword.isHidden = true
            lblPasswordError.isHidden = false
        }
        else
        {
            lblPassword.isHidden = false
            lblPasswordError.isHidden = true
        }
    }
    
    
    
    //------------------------------
    // MARK: User Defined Functions
    //------------------------------
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        self.view.endEditing(true)
    }
    
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        textField.resignFirstResponder()
        self.view.endEditing(true)
        return true
    }
    
    
    func registerKeyboardNotifications()
    {
        NotificationCenter.default.addObserver(self,selector: #selector(keyboardWillShow(notification:)),name: UIResponder.keyboardWillShowNotification,object: nil)
        
        NotificationCenter.default.addObserver(self,selector: #selector(keyboardWillHide(notification:)),name: UIResponder.keyboardWillHideNotification,object: nil)
    }
    
    
    func textFieldDidBeginEditing(_ textField: UITextField)
    {
        scrollView.setContentOffset(CGPoint(x: 0, y: 0), animated: true)
    }
    
    
    
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        scrollView.setContentOffset(CGPoint(x: 0, y: 0), animated: true)
    }
    
    
    
    
    @objc func keyboardWillShow(notification: NSNotification)
    {
        let userInfo: NSDictionary = notification.userInfo! as NSDictionary
        let keyboardInfo = userInfo[UIResponder.keyboardFrameEndUserInfoKey] as! NSValue
        let keyboardSize = keyboardInfo.cgRectValue.size
        let contentInsets = UIEdgeInsets(top: 0, left: 0, bottom: keyboardSize.height, right: 0)
        scrollView.contentInset = contentInsets
        scrollView.scrollIndicatorInsets = contentInsets
    }
    
    @objc func keyboardWillHide(notification: NSNotification)
    {
        scrollView.contentInset = .zero
        scrollView.scrollIndicatorInsets = .zero
    }
    
    
    
    
    
    
    
    
    
    
    //----------------------
    // MARK: Button Actions
    //----------------------
    
    
    @IBAction func btnLogin(_ sender: UIButton)
    {
        let obj = storyboard?.instantiateViewController(withIdentifier: "mainscreenVC") as! mainscreenVC
        
        navigationController?.pushViewController(obj, animated: true)
    }
    

    
    @IBAction func btnCreateAccountTUI(_ sender: UIButton)
    {
        let obj = storyboard?.instantiateViewController(withIdentifier: "RegisterAsVC") as! RegisterAsVC
        
        navigationController?.pushViewController(obj, animated: true)
    }
    
    
    
    
    //----------------------
    // MARK: Web Service
    //----------------------
    
    
    
    
}
