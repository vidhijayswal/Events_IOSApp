//
//  ContactUsVC.swift
//  LMM
//
//  Created by Ashutosh Jani on 14/09/18.
//  Copyright © 2018 Qrioustech. All rights reserved.
//

import UIKit
//import Alamofire
//import SVProgressHUD

class AddBusinessVC: UIViewController, UITextFieldDelegate,UITextViewDelegate
{
    
    //------------------------------------
    // MARK: Outlets
    //------------------------------------
   // @IBOutlet weak var lblDescription: UILabel!
    
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var lblNamePlaceholder: UILabel!
    @IBOutlet weak var lblNameError: UILabel!
    @IBOutlet weak var lblEmailPlaceholder: UILabel!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var lblEmailError: UILabel!
    @IBOutlet weak var lblPhonePlaceholder: UILabel!
    @IBOutlet weak var txtPhone: UITextField!
    @IBOutlet weak var lblPhoneError: UILabel!
    @IBOutlet weak var lblAddressPlaceholder: UILabel!
    @IBOutlet weak var txtViewAddress: UITextView!
    @IBOutlet weak var lblAddressError: UILabel!
//@IBOutlet weak var btnContact: UIButton!
    @IBOutlet weak var ScrollView: UIScrollView!
    
    @IBOutlet weak var backGroundView: UIView!
    @IBOutlet weak var headerView: UIView!
    
    //------------------------------------
    // MARK: Identifiers
    //------------------------------------
    
    var internetTimer = Timer()
    
    //------------------------------------
    // MARK: View Life Cycle
    //------------------------------------

    override func viewDidLoad() {
        super.viewDidLoad()

      
   
//        btnContact.layer.borderColor = UIColor(rgb: Constant.tabbarBackgroundColor).cgColor
        
        lblNameError.isHidden = true
        
        lblNamePlaceholder.isHidden = true
        
        lblEmailError.isHidden = true
        
        lblEmailPlaceholder.isHidden = true
        
        lblPhoneError.isHidden = true
        
        lblPhonePlaceholder.isHidden = true
        
        lblAddressError.isHidden = true
        
        lblAddressPlaceholder.isHidden = true
        
//-----------------------------------------------------------

        
        
        txtName.delegate = self
        
        txtEmail.delegate = self
        
        txtPhone.delegate = self
        
        txtViewAddress.delegate = self

//-----------------------------------------------------------

       
        
        txtName.addTarget(self, action: #selector(txtNameValueChange), for: .editingChanged)
      
        txtEmail.addTarget(self, action: #selector(txtEmailValueChange), for: .editingChanged)
        
        txtPhone.addTarget(self, action: #selector(txtSubjectValueChange), for: .editingChanged)
        
     //   txtViewAddress.addTarget(self, action: #selector(txtMessageValueChange), for: .editingChanged)

//-----------------------------------------------------------

        
        txtName.attributedPlaceholder = NSMutableAttributedString(string: "Enter Name",attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray])
        
        txtEmail.attributedPlaceholder = NSMutableAttributedString(string: "Enter Email ID",attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray])
        
        txtPhone.attributedPlaceholder = NSMutableAttributedString(string: "Enter Phone",attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray])
        
        //txtViewAddress.attributedPlaceholder = NSMutableAttributedString(string: "Enter Address",attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray])
       
       // self.backGroundView.addTopRoundedCornerToView(targetView:backGroundView, desiredCurve: 0.9)

        // Do any additional setup after loading the view.
        
        
      
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
//        scrollViewHeight.constant = 370 + lblDescription.bounds.height
//        print(scrollViewHeight.constant)
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

 
    //------------------------------------
    // MARK: Delegate Methods
    //------------------------------------
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return true
    }
    
    //------------------------------------
    // MARK: User Defined Functions
    //------------------------------------
    
    @objc func txtNameValueChange()
    {
        if txtName.text == ""
        {
            lblNamePlaceholder.isHidden = true
            lblNameError.isHidden = false
        }
        else
        {
            lblNamePlaceholder.isHidden = false
            lblNameError.isHidden = true
        }
    }
    
    @objc func txtEmailValueChange()
    {
        if txtEmail.text == ""
        {
            lblEmailPlaceholder.isHidden = true
            lblEmailError.isHidden = false
        }
        else
        {
            lblEmailPlaceholder.isHidden = false
            lblEmailError.isHidden = true
        }
        
        
    }
    @objc func txtSubjectValueChange()
    {
        if txtPhone.text == ""
        {
            lblPhonePlaceholder.isHidden = true
            lblPhoneError.isHidden = false
        }
        else
        {
            lblPhonePlaceholder.isHidden = false
            lblPhoneError.isHidden = true
        }
    }
    
    
    
    @objc func txtMessageValueChange()
    {
        
        if txtViewAddress.text == ""
        {
            lblAddressPlaceholder.isHidden = true
            lblAddressError.isHidden = false
        }
        else
        {
            lblAddressPlaceholder.isHidden = false
            lblAddressError.isHidden = true
        }
    }
    
    
//-----------------------------------------------------------

    
    @objc func keyboardWillShow(notification:NSNotification){
        //give room at the bottom of the scroll view, so it doesn't cover up anything the user needs to tap
        var userInfo = notification.userInfo!
        var keyboardFrame:CGRect = (userInfo[UIResponder.keyboardFrameBeginUserInfoKey] as! NSValue).cgRectValue
        keyboardFrame = self.view.convert(keyboardFrame, from: nil)
        
        var contentInset:UIEdgeInsets = self.ScrollView.contentInset
        contentInset.bottom = keyboardFrame.size.height + 40
        ScrollView.contentInset = contentInset
    }
    
    @objc func keyboardWillHide(notification:NSNotification){
        let contentInset:UIEdgeInsets = UIEdgeInsets.zero
        ScrollView.contentInset = contentInset
    }
    
    //------------------------------------
    // MARK: Button Actions
    //------------------------------------
    
    @IBAction func btnBackTUI(_ sender: UIButton)
    {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnNextTUI(_ sender: UIButton)
    {
//        if txtName.text == "" || (txtName.text! as NSString).trimmingCharacters(in: .whitespaces).isEmpty
//        {
//            lblNameError.isHidden = false
//        }
//        else if txtEmail.text == "" || (txtEmail.text! as NSString).trimmingCharacters(in: .whitespaces).isEmpty
//
//        {
//            lblEmailError.isHidden = false
//        }
//        else if validateEmailWithString(txtEmail.text! as NSString)
//        {
//            lblEmailError.text = "Please enter valid Email ID"
//        }
//        else if txtPhone.text == "" || (txtPhone.text! as NSString).trimmingCharacters(in: .whitespaces).isEmpty
//
//        {
//            lblPhoneError.isHidden = false
//        }
//        else if txtViewAddress.text == "" || (txtViewAddress.text! as NSString).trimmingCharacters(in: .whitespaces).isEmpty
//
//        {
//            lblAddressError.isHidden = false
//        }
//        else
//        {
//
            let obj = storyboard?.instantiateViewController(withIdentifier: "CreateBusinessVC") as! CreateBusinessVC
            
            
            navigationController?.pushViewController(obj, animated: true)
            
           // contactUsAPI()
//        }
        
    }
    
    
    
    //------------------------------------
    // MARK: Web Services
    //------------------------------------

    
   
}


//------------------------------------
// MARK: Extension
//------------------------------------



func validateEmailWithString(_ Email: NSString) -> Bool {
    //let emailRegEx = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$"
    let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
    
    let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
    return !emailTest.evaluate(with: Email)
}



extension UIView {
    
    func addTopRoundedCornerToView(targetView:UIView?, desiredCurve:CGFloat?)
    {
        let offset:CGFloat =  targetView!.frame.width/desiredCurve!
        let bounds: CGRect = targetView!.bounds
      
        let rectBounds: CGRect = CGRect(x: bounds.origin.x, y: bounds.origin.y + bounds.size.height / 2 , width:  bounds.size.width, height: bounds.size.height / 2)
        
//        let rectBounds: CGRect = CGRectMake(bounds.origin.x, bounds.origin.y+bounds.size.height / 2, bounds.size.width, bounds.size.height / 2)
        
        let rectPath: UIBezierPath = UIBezierPath(rect: rectBounds)
       let ovalBounds: CGRect = CGRect(x: bounds.origin.x - offset / 2, y: bounds.origin.y, width: bounds.size.width + offset, height: bounds.size.height)
        //let ovalBounds: CGRect = CGRect(bounds.origin.x - offset / 2, bounds.origin.y, bounds.size.width + offset, bounds.size.height)
        let ovalPath: UIBezierPath = UIBezierPath(ovalIn: ovalBounds)
        rectPath.append(ovalPath)
        
        // Create the shape layer and set its path
        let maskLayer: CAShapeLayer = CAShapeLayer()
        maskLayer.frame = bounds
        maskLayer.path = rectPath.cgPath
        
        // Set the newly created shape layer as the mask for the view's layer
        targetView!.layer.mask = maskLayer
    }
}
