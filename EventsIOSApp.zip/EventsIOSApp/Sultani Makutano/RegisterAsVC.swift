//
//  RegisterAsVC.swift
//  Sultani Makutano
//
//  Created by vidhi jayswal on 08/06/19.
//  Copyright © 2019 vidhi jayswal. All rights reserved.
//

import UIKit

class RegisterAsVC: UIViewController
{

    
    
    //-------------------
    // MARK: Outlets
    //-------------------
    
    
    
    
    
    
    
    
    
    
    
    //-------------------
    // MARK: Identifiers
    //-------------------
    
    
    
    
    
    
    
    
    
    //-----------------------
    // MARK: View Life Cycle
    //-----------------------
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        
    }
    
    
    
    //-----------------------------
    // MARK: User Defined Functions
    //-----------------------------
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    //----------------------
    // MARK: Button Actions
    //----------------------
    
    
    @IBAction func btnEventOrganizor(_ sender: UIButton)
    {
        
        
        let obj = storyboard?.instantiateViewController(withIdentifier: "RegisterVC") as! RegisterVC

        UserDefaults.standard.set("1", forKey: "eventorganizor")
        
        obj.role = UserDefaults.standard.integer(forKey: "eventorganizor")
            
        navigationController?.pushViewController(obj, animated: true)
    }
    
    
    @IBAction func btnBusinessOwner(_ sender: UIButton)
    {
        
        
        let obj = storyboard?.instantiateViewController(withIdentifier: "RegisterVC") as! RegisterVC
        
        UserDefaults.standard.set("2", forKey: "businessowner")
        obj.role = UserDefaults.standard.integer(forKey: "businessowner")
        
        navigationController?.pushViewController(obj, animated: true)
    }
    
    @IBAction func btnVisitor(_ sender: UIButton)
    {
        
        
        let obj = storyboard?.instantiateViewController(withIdentifier: "RegisterVC") as! RegisterVC
        
        UserDefaults.standard.set("0", forKey: "visitor")
        obj.role = UserDefaults.standard.integer(forKey: "visitor")
        
        
        navigationController?.pushViewController(obj, animated: true)
    }
    
    

    
    
    
    
    //-------------------
    // MARK: Web Service
    //-------------------
    
    
    
    
}
