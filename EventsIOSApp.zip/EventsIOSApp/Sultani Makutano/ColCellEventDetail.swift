//
//  ColCellEventDetail.swift
//  Sultani Mukhtano
//
//  Created by sanjay bhatia on 07/06/19.
//  Copyright © 2019 sanjay bhatia. All rights reserved.
//

import UIKit

class ColCellEventDetail: UICollectionViewCell


{
    
    @IBOutlet weak var imgEventDetailA: UIImageView!
    
    @IBOutlet weak var imgEventDetailB: UIImageView!
}
