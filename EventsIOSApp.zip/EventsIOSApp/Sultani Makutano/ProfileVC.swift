//
//  ProfileVC.swift
//  Sultani Makutano
//
//  Created by vidhi jayswal on 08/06/19.
//  Copyright © 2019 vidhi jayswal. All rights reserved.
//

import UIKit
import CTKFlagPhoneNumber

class ProfileVC: UIViewController, UITextFieldDelegate
{
    
    
    
    //-----------------
    // MARK: Outlets
    //-----------------
    
    
    @IBOutlet weak var txtPhone: CTKFlagPhoneNumberTextField!
    
    
    @IBOutlet weak var lblName: UILabel!
    
    
    @IBOutlet weak var lblEmail: UILabel!
    
    @IBOutlet weak var curvedView: UIView!
    
    
    
    
    
    //-----------------------
    // MARK: Identifiers
    //-----------------------
    
    
    
    
    
    
    
    
    
    
    //-----------------------
    // MARK: View Life Cycle
    //-----------------------

    override func viewDidLoad()
    {
        super.viewDidLoad()
        

        
    }
    
    
    
    //-----------------------------
    // MARK: User Defined Function
    //-----------------------------
    
    
    
    
    
    
    
    
    
    //-----------------------
    // MARK: Button Action
    //-----------------------
    
    
    
    
    
    
    
    
    //-----------------------
    // MARK: Web Service
    //-----------------------

    

}

